'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Home, TrendingUp, Search, Clock, BookmarkPlus, Play,
  Star, ChevronLeft, ChevronRight, Sun, Moon,
  Share2, ArrowUp, Film, Sparkles
} from 'lucide-react';

// Types
interface Anime {
  id: number;
  title: string;
  titleEnglish: string;
  image: string;
  smallImage: string;
  description: string;
  fullDescription: string;
  genre: string[];
  rating: number;
  year: string | number;
  status: string;
  episodes: number;
  type: string;
  aired: string;
  studios: string[];
  isAdult: boolean;
}

interface Character {
  id: number;
  name: string;
  image: string;
  role: string;
}

// Fallback mock data when API is unreachable
const FALLBACK_ANIME: Anime[] = [
  { id: 1, title: 'Shingeki no Kyojin: The Final Season', titleEnglish: 'Attack on Titan: The Final Season', image: 'https://cdn.myanimelist.net/images/anime/1000/110531l.jpg', smallImage: 'https://cdn.myanimelist.net/images/anime/1000/110531.jpg', description: 'Humanity lives within cities surrounded by enormous walls due to the Titans, gigantic humanoid beings.', fullDescription: 'Humanity lives within cities surrounded by enormous walls due to the Titans, gigantic humanoid beings.', genre: ['Action', 'Drama', 'Fantasy'], rating: 9.0, year: 2022, status: 'Finished Airing', episodes: 87, type: 'TV', aired: 'Jan 2022 to Nov 2023', studios: ['MAPPA'], isAdult: false },
  { id: 2, title: 'Jujutsu Kaisen 2nd Season', titleEnglish: 'Jujutsu Kaisen 2nd Season', image: 'https://cdn.myanimelist.net/images/anime/1792/138022l.jpg', smallImage: 'https://cdn.myanimelist.net/images/anime/1792/138022.jpg', description: 'The second season of Jujutsu Kaisen. Hidden in the shadows, an ancient curse awakens.', fullDescription: 'The second season of Jujutsu Kaisen. Hidden in the shadows, an ancient curse awakens.', genre: ['Action', 'Fantasy'], rating: 8.7, year: 2023, status: 'Finished Airing', episodes: 23, type: 'TV', aired: 'Jul 2023 to Dec 2023', studios: ['MAPPA'], isAdult: false },
  { id: 3, title: 'Spy x Family Season 2', titleEnglish: 'SPY x FAMILY Season 2', image: 'https://cdn.myanimelist.net/images/anime/1441/139629l.jpg', smallImage: 'https://cdn.myanimelist.net/images/anime/1441/139629.jpg', description: 'The Forger family continues their unconventional life together while hiding their true identities.', fullDescription: 'The Forger family continues their unconventional life together while hiding their true identities.', genre: ['Action', 'Comedy'], rating: 8.5, year: 2023, status: 'Finished Airing', episodes: 12, type: 'TV', aired: 'Oct 2023 to Dec 2023', studios: ['Wit Studio', 'CloverWorks'], isAdult: false },
  { id: 4, title: 'Frieren: Beyond Journey\'s End', titleEnglish: 'Frieren: Beyond Journey\'s End', image: 'https://cdn.myanimelist.net/images/anime/1015/138006l.jpg', smallImage: 'https://cdn.myanimelist.net/images/anime/1015/138006.jpg', description: 'After the party of heroes defeated the Demon King, the aftermath of their quest begins.', fullDescription: 'After the party of heroes defeated the Demon King, the aftermath of their quest begins.', genre: ['Adventure', 'Drama', 'Fantasy'], rating: 9.1, year: 2023, status: 'Currently Airing', episodes: 28, type: 'TV', aired: 'Sep 2023 to Mar 2024', studios: ['Madhouse'], isAdult: false },
  { id: 5, title: 'Solo Leveling', titleEnglish: 'Solo Leveling', image: 'https://cdn.myanimelist.net/images/anime/1314/142680l.jpg', smallImage: 'https://cdn.myanimelist.net/images/anime/1314/142680.jpg', description: 'In a world where hunters must battle deadly monsters, the weakest hunter gains a mysterious power.', fullDescription: 'In a world where hunters must battle deadly monsters, the weakest hunter gains a mysterious power.', genre: ['Action', 'Adventure', 'Fantasy'], rating: 8.3, year: 2024, status: 'Currently Airing', episodes: 12, type: 'TV', aired: 'Jan 2024 to Mar 2024', studios: ['A-1 Pictures'], isAdult: false },
  { id: 6, title: 'Oshi no Ko', titleEnglish: 'Oshi No Ko', image: 'https://cdn.myanimelist.net/images/anime/1812/134736l.jpg', smallImage: 'https://cdn.myanimelist.net/images/anime/1812/134736.jpg', description: 'A doctor who is a fan of a young idol is reborn as her son, uncovering the dark side of the entertainment industry.', fullDescription: 'A doctor who is a fan of a young idol is reborn as her son, uncovering the dark side of the entertainment industry.', genre: ['Drama', 'Supernatural'], rating: 8.9, year: 2023, status: 'Finished Airing', episodes: 11, type: 'TV', aired: 'Apr 2023 to Jun 2023', studios: ['Doga Kobo'], isAdult: false },
];

const FALLBACK_HERO: Anime = FALLBACK_ANIME[3];

// API helpers
const api = {
  async getPopular(): Promise<Anime[]> {
    try {
      const res = await fetch('/api/anime');
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json();
      return Array.isArray(data) ? data : FALLBACK_ANIME;
    } catch { return FALLBACK_ANIME; }
  },
  async getAnimeById(id: number): Promise<Anime> {
    const res = await fetch(`/api/anime/${id}`);
    if (!res.ok) throw new Error(`API error: ${res.status}`);
    return res.json();
  },
  async search(query: string, page = 1, adult = false): Promise<{ results: Anime[]; pagination: any }> {
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&page=${page}&adult=${adult}`);
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json();
      return data.results ? data : { results: [], pagination: {} };
    } catch { return { results: [], pagination: {} }; }
  },
  async getGenres(): Promise<any[]> {
    try {
      const res = await fetch('/api/genres');
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      return res.json();
    } catch { return []; }
  },
  async getTop(filter = 'bypopularity', adult = false): Promise<Anime[]> {
    try {
      const res = await fetch(`/api/top?filter=${filter}&adult=${adult}`);
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json();
      return Array.isArray(data) ? data : FALLBACK_ANIME;
    } catch { return FALLBACK_ANIME; }
  },
  async getRandom(): Promise<Anime> {
    try {
      const res = await fetch('/api/random');
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json();
      return data.id ? data : FALLBACK_HERO;
    } catch { return FALLBACK_HERO; }
  },
  async getRecommendations(id: number): Promise<any[]> {
    try {
      const res = await fetch(`/api/anime/${id}/recommendations`);
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      return res.json();
    } catch { return []; }
  },
  async getCharacters(id: number): Promise<Character[]> {
    try {
      const res = await fetch(`/api/anime/${id}/characters`);
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      return res.json();
    } catch { return []; }
  },
};

// LocalStorage helpers
function getStore<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch { return fallback; }
}

function setStore(key: string, value: any) {
  if (typeof window === 'undefined') return;
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

// Toast system
let toastCallback: ((msg: string, type: string) => void) | null = null;

function showToast(message: string, type = 'info') {
  toastCallback?.(message, type);
}

// =================== COMPONENTS ===================

// Toast Component
function ToastContainer() {
  const [toasts, setToasts] = useState<{ id: number; message: string; type: string }[]>([]);

  useEffect(() => {
    toastCallback = (message, type) => {
      const id = Date.now();
      setToasts(prev => [...prev, { id, message, type }]);
      setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 4000);
    };
    return () => { toastCallback = null; };
  }, []);

  const colors: Record<string, string> = {
    info: 'bg-indigo-500', success: 'bg-emerald-500', warning: 'bg-amber-500', error: 'bg-red-500'
  };

  return (
    <div className="fixed top-4 right-4 z-[200] flex flex-col gap-2 pointer-events-none">
      {toasts.map(t => (
        <div key={t.id}
          className={`${colors[t.type] || colors.info} text-white px-4 py-2 rounded-lg shadow-lg pointer-events-auto
            animate-[slideIn_0.3s_ease] text-sm font-medium`}>
          {t.message}
        </div>
      ))}
    </div>
  );
}

// Anime Card
function AnimeCard({ anime, onClick, progress }: { anime: Anime; onClick: () => void; progress?: number }) {
  return (
    <div onClick={onClick} className="group cursor-pointer">
      <div className="relative rounded-xl overflow-hidden bg-zinc-800 transition-all duration-300 group-hover:scale-[1.03] group-hover:shadow-xl group-hover:shadow-indigo-500/10">
        <img src={anime.image} alt={anime.title} className="w-full aspect-[3/4] object-cover"
          loading="lazy" onError={(e) => { (e.target as HTMLImageElement).src = ''; (e.target as HTMLImageElement).className = 'w-full aspect-[3/4] bg-zinc-700'; }} />
        {anime.type && anime.type !== 'TV' && (
          <span className="absolute top-2 left-2 px-2 py-0.5 bg-indigo-500 text-white text-xs font-semibold rounded-md">
            {anime.type}
          </span>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-8">
          <div className="w-12 h-12 bg-indigo-500 rounded-full flex items-center justify-center shadow-lg">
            <Play className="w-5 h-5 text-white fill-white" />
          </div>
        </div>
        {progress !== undefined && progress > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-zinc-600">
            <div className="h-full bg-indigo-500 rounded-r" style={{ width: `${progress}%` }} />
          </div>
        )}
      </div>
      <div className="mt-2 px-0.5">
        <h3 className="text-sm font-semibold text-zinc-100 truncate">{anime.title}</h3>
        <div className="flex items-center gap-2 text-xs text-zinc-400 mt-0.5">
          {anime.rating > 0 && <span className="flex items-center gap-1 text-amber-400"><Star className="w-3 h-3 fill-amber-400" />{anime.rating}</span>}
          <span>{anime.type}</span>
        </div>
      </div>
    </div>
  );
}

// Skeleton Grid
function SkeletonGrid({ count = 12 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="animate-pulse">
          <div className="aspect-[3/4] bg-zinc-800 rounded-xl" />
          <div className="mt-2 h-4 bg-zinc-800 rounded w-3/4" />
          <div className="mt-1 h-3 bg-zinc-800 rounded w-1/2" />
        </div>
      ))}
    </div>
  );
}

// Genre Chips
function GenreChips({ onSelect, selected }: { onSelect: (id: number | null) => void; selected: number | null }) {
  const [genres, setGenres] = useState<any[]>([]);

  useEffect(() => {
    api.getGenres().then(g => setGenres(g.slice(0, 20))).catch(() => {});
  }, []);

  return (
    <div className="flex flex-wrap gap-2">
      {genres.map(g => (
        <button key={g.mal_id} onClick={() => onSelect(selected === g.mal_id ? null : g.mal_id)}
          className={`px-3 py-1 rounded-full text-sm font-medium transition-all duration-200
            ${selected === g.mal_id
              ? 'bg-indigo-500 text-white shadow-md shadow-indigo-500/25'
              : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-white border border-zinc-700'}`}>
          {g.name}
        </button>
      ))}
    </div>
  );
}

// Pagination
function Pagination({ page, totalPages, onPageChange }: { page: number; totalPages: number; onPageChange: (p: number) => void }) {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-center gap-2 py-8">
      <button onClick={() => onPageChange(page - 1)} disabled={page <= 1}
        className="p-2 rounded-lg bg-zinc-800 text-zinc-300 disabled:opacity-40 hover:bg-zinc-700 transition-colors">
        <ChevronLeft className="w-4 h-4" />
      </button>
      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
        const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
        if (p > totalPages) return null;
        return (
          <button key={p} onClick={() => onPageChange(p)}
            className={`min-w-[36px] h-9 rounded-lg text-sm font-medium transition-colors
              ${p === page ? 'bg-indigo-500 text-white' : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'}`}>
            {p}
          </button>
        );
      })}
      <button onClick={() => onPageChange(page + 1)} disabled={page >= totalPages}
        className="p-2 rounded-lg bg-zinc-800 text-zinc-300 disabled:opacity-40 hover:bg-zinc-700 transition-colors">
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}

// =================== PAGES ===================

// Home Page
function HomePage({ onNavigate }: { onNavigate: (route: string) => void }) {
  const [popular, setPopular] = useState<Anime[]>([]);
  const [hero, setHero] = useState<Anime | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedGenre, setSelectedGenre] = useState<number | null>(null);
  const [genreAnime, setGenreAnime] = useState<Anime[]>([]);

  useEffect(() => {
    Promise.all([api.getPopular(), api.getRandom()])
      .then(([pop, rand]) => {
        setPopular(pop);
        setHero(rand);
      })
      .catch(() => showToast('Failed to load anime', 'error'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!selectedGenre) return;
    let cancelled = false;
    fetch(`/api/search?q=&page=1&genre=${selectedGenre}`)
      .then(r => r.json())
      .then(d => { if (!cancelled) setGenreAnime(d.results || []); })
      .catch(() => { if (!cancelled) setGenreAnime([]); });
    return () => { cancelled = true; };
  }, [selectedGenre]);

  if (loading) return <SkeletonGrid />;

  const displayAnime = Array.isArray(selectedGenre ? genreAnime : popular) ? (selectedGenre ? genreAnime : popular) : [];

  return (
    <div className="space-y-8">
      {/* Hero Banner */}
      {hero && (
        <div className="relative rounded-2xl overflow-hidden min-h-[320px] md:min-h-[400px]"
          style={{ background: `linear-gradient(to right, #09090b 40%, transparent), url(${hero.image}) center/cover no-repeat` }}>
          <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent" />
          <div className="relative z-10 flex items-center h-full min-h-[320px] md:min-h-[400px] p-6 md:p-12">
            <div className="max-w-lg">
              <h1 className="text-3xl md:text-5xl font-bold text-white mb-3 leading-tight"
                style={{ fontFamily: "var(--font-instrument-serif), ui-serif, Georgia, serif" }}>{hero.title}</h1>
              <p className="text-zinc-300 mb-6 line-clamp-3 text-sm md:text-base">{hero.description}</p>
              <div className="flex gap-3">
                <button onClick={() => onNavigate('#/watch/' + hero.id + '/1')}
                  className="flex items-center gap-2 px-6 py-3 bg-indigo-500 hover:bg-indigo-400 text-white rounded-xl font-semibold transition-colors shadow-lg shadow-indigo-500/25">
                  <Play className="w-5 h-5 fill-white" /> Watch Now
                </button>
                <button onClick={() => onNavigate('#/anime/' + hero.id)}
                  className="flex items-center gap-2 px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl font-semibold transition-colors border border-zinc-700">
                  Details
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Genre Filter */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2"><Sparkles className="w-5 h-5 text-indigo-400" /> Browse by Genre</h2>
          {selectedGenre && <button onClick={() => setSelectedGenre(null)} className="text-sm text-indigo-400 hover:text-indigo-300">Clear Filter</button>}
        </div>
        <GenreChips onSelect={setSelectedGenre} selected={selectedGenre} />
      </div>

      {/* Anime Grid */}
      <div>
        <h2 className="text-xl font-bold text-white mb-4">
          {selectedGenre ? 'Filtered Results' : '🔥 Popular Anime'}
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {displayAnime.map(a => (
            <AnimeCard key={a.id} anime={a} onClick={() => onNavigate('#/anime/' + a.id)} />
          ))}
        </div>
        {displayAnime.length === 0 && (
          <div className="text-center py-16 text-zinc-500">No anime found</div>
        )}
      </div>
    </div>
  );
}

// Search Page
function SearchPage({ onNavigate }: { onNavigate: (route: string) => void }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Anime[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [suggestions, setSuggestions] = useState<Anime[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const doSearch = useCallback(async (q: string, p = 1) => {
    if (!q.trim()) { setResults([]); return; }
    setLoading(true);
    try {
      const data = await api.search(q, p);
      setResults(data.results || []);
      setTotalPages(data.pagination?.last_visible_page || 1);
      setPage(p);
    } catch { showToast('Search failed', 'error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (query.length >= 2) {
        api.search(query, 1).then(d => setSuggestions((d.results || []).slice(0, 5))).catch(() => {});
        setShowSuggestions(true);
      } else {
        setSuggestions([]);
        setShowSuggestions(false);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setShowSuggestions(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white" style={{ fontFamily: "var(--font-instrument-serif), ui-serif, Georgia, serif" }}>Search Anime</h1>

      <div ref={searchRef} className="relative max-w-xl">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
          <input type="text" value={query} onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && doSearch(query)}
            onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
            placeholder="Search for anime..." autoFocus
            className="w-full pl-10 pr-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder:text-zinc-500 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all" />
        </div>
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-zinc-800 border border-zinc-700 rounded-xl shadow-2xl overflow-hidden z-50">
            {suggestions.map(s => (
              <div key={s.id} onClick={() => { setQuery(s.title); setShowSuggestions(false); onNavigate('#/anime/' + s.id); }}
                className="flex items-center gap-3 px-4 py-2 hover:bg-zinc-700 cursor-pointer transition-colors">
                <img src={s.smallImage || s.image} alt="" className="w-8 h-10 object-cover rounded" />
                <div>
                  <div className="text-sm text-white font-medium">{s.title}</div>
                  <div className="text-xs text-zinc-400">{s.type} {s.year}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {loading ? <SkeletonGrid /> : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
            {results.map(a => (
              <AnimeCard key={a.id} anime={a} onClick={() => onNavigate('#/anime/' + a.id)} />
            ))}
          </div>
          {results.length === 0 && query && !loading && (
            <div className="text-center py-16 text-zinc-500">No results for &ldquo;{query}&rdquo;</div>
          )}
          <Pagination page={page} totalPages={totalPages} onPageChange={p => doSearch(query, p)} />
        </>
      )}
    </div>
  );
}

// Anime Detail Page
function AnimeDetailPage({ animeId, onNavigate }: { animeId: number; onNavigate: (route: string) => void }) {
  const [anime, setAnime] = useState<Anime | null>(null);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isInWatchlist, setIsInWatchlist] = useState(false);
  const prevAnimeIdRef = useRef<number | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (prevAnimeIdRef.current !== animeId) {
      prevAnimeIdRef.current = animeId;
    }
    api.getAnimeById(animeId)
      .then(a => {
        if (cancelled) return;
        setAnime(a);
        setLoading(false);
        setIsInWatchlist(getStore<Anime[]>('xan-watchlist', []).some(w => w.id === a.id));
      })
      .catch(() => {
        if (!cancelled) { showToast('Failed to load anime', 'error'); setLoading(false); }
      });

    Promise.all([api.getCharacters(animeId), api.getRecommendations(animeId)])
      .then(([chars, recs]) => { if (!cancelled) { setCharacters(chars); setRecommendations(recs); } })
      .catch(() => {});

    return () => { cancelled = true; };
  }, [animeId]);

  const toggleWatchlist = () => {
    if (!anime) return;
    const wl = getStore<Anime[]>('xan-watchlist', []);
    const idx = wl.findIndex(w => w.id === anime.id);
    if (idx >= 0) {
      wl.splice(idx, 1);
      showToast('Removed from watchlist', 'info');
    } else {
      wl.push(anime);
      showToast('Added to watchlist', 'success');
    }
    setStore('xan-watchlist', wl);
    setIsInWatchlist(idx < 0);
  };

  if (loading) return <SkeletonGrid count={1} />;
  if (!anime) return <div className="text-center py-16 text-zinc-500">Anime not found</div>;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row gap-6 md:gap-8">
        <div className="flex-shrink-0 w-full md:w-64">
          <img src={anime.image} alt={anime.title} className="w-full rounded-xl shadow-lg" />
        </div>
        <div className="flex-1">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3" style={{ fontFamily: "var(--font-instrument-serif), ui-serif, Georgia, serif" }}>
            {anime.title}
          </h1>
          <div className="flex flex-wrap gap-2 mb-4">
            {anime.rating > 0 && <span className="px-2.5 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-sm font-medium flex items-center gap-1"><Star className="w-3.5 h-3.5 fill-indigo-400" />{anime.rating}</span>}
            {anime.type && <span className="px-2.5 py-1 bg-zinc-800 text-zinc-300 rounded-full text-sm">{anime.type}</span>}
            {anime.year && anime.year !== 'Unknown' && <span className="px-2.5 py-1 bg-zinc-800 text-zinc-300 rounded-full text-sm">{anime.year}</span>}
            {anime.status && <span className="px-2.5 py-1 bg-zinc-800 text-zinc-300 rounded-full text-sm">{anime.status}</span>}
          </div>
          <p className="text-zinc-300 leading-relaxed mb-6">{anime.fullDescription || anime.description || 'No description available.'}</p>
          <div className="grid grid-cols-2 gap-3 mb-6 text-sm">
            <div><span className="text-zinc-500 uppercase text-xs tracking-wider">Episodes</span><div className="text-white font-medium">{anime.episodes || 'Unknown'}</div></div>
            <div><span className="text-zinc-500 uppercase text-xs tracking-wider">Status</span><div className="text-white font-medium">{anime.status || 'Unknown'}</div></div>
            <div><span className="text-zinc-500 uppercase text-xs tracking-wider">Aired</span><div className="text-white font-medium">{anime.aired || 'Unknown'}</div></div>
            <div><span className="text-zinc-500 uppercase text-xs tracking-wider">Studios</span><div className="text-white font-medium">{anime.studios?.join(', ') || 'Unknown'}</div></div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => onNavigate('#/watch/' + anime.id + '/1')}
              className="flex items-center gap-2 px-6 py-2.5 bg-indigo-500 hover:bg-indigo-400 text-white rounded-xl font-semibold transition-colors shadow-lg shadow-indigo-500/25">
              <Play className="w-4 h-4 fill-white" /> Watch Now
            </button>
            <button onClick={toggleWatchlist}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-semibold transition-colors border
                ${isInWatchlist ? 'bg-indigo-500/10 border-indigo-500/50 text-indigo-400' : 'bg-zinc-800 border-zinc-700 text-white hover:bg-zinc-700'}`}>
              <BookmarkPlus className="w-4 h-4" /> {isInWatchlist ? 'In Watchlist' : 'Add to Watchlist'}
            </button>
          </div>
        </div>
      </div>

      {/* Episodes */}
      {anime.episodes > 0 && (
        <div>
          <h3 className="text-lg font-bold text-white mb-4">Episodes</h3>
          <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12 gap-2">
            {Array.from({ length: Math.min(anime.episodes, 24) }, (_, i) => i + 1).map(ep => (
              <button key={ep} onClick={() => onNavigate('#/watch/' + anime.id + '/' + ep)}
                className="py-2 text-sm rounded-lg bg-zinc-800 text-zinc-300 border border-zinc-700 hover:bg-indigo-500/10 hover:text-indigo-400 hover:border-indigo-500/50 transition-colors">
                {ep}
              </button>
            ))}
            {anime.episodes > 24 && <span className="py-2 text-sm text-zinc-500 flex items-center justify-center">+{anime.episodes - 24}</span>}
          </div>
        </div>
      )}

      {/* Characters */}
      {characters.length > 0 && (
        <div>
          <h3 className="text-lg font-bold text-white mb-4">Characters</h3>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4">
            {characters.slice(0, 8).map(c => (
              <div key={c.id} className="text-center">
                <img src={c.image} alt={c.name} className="w-16 h-16 md:w-20 md:h-20 rounded-full object-cover mx-auto mb-1.5 ring-2 ring-zinc-700"
                  onError={(e) => { (e.target as HTMLImageElement).src = ''; (e.target as HTMLImageElement).className = 'w-16 h-16 md:w-20 md:h-20 rounded-full bg-zinc-700 mx-auto mb-1.5'; }} />
                <div className="text-xs text-zinc-300 truncate">{c.name}</div>
                <div className="text-[10px] text-zinc-500">{c.role}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <div>
          <h3 className="text-lg font-bold text-white mb-4">Recommendations</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
            {recommendations.slice(0, 6).map(r => (
              <AnimeCard key={r.id} anime={r} onClick={() => onNavigate('#/anime/' + r.id)} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Watch Page
function WatchPage({ animeId, episodeId, onNavigate }: { animeId: number; episodeId: number; onNavigate: (route: string) => void }) {
  const [anime, setAnime] = useState<Anime | null>(null);

  useEffect(() => {
    api.getAnimeById(animeId).then(setAnime).catch(() => {});

    // Add to history
    const history = getStore<{ animeId: number; episodeId: number; timestamp: number }[]>('xan-history', []);
    const filtered = history.filter(h => !(h.animeId === animeId && h.episodeId === episodeId));
    filtered.unshift({ animeId, episodeId, timestamp: Date.now() });
    setStore('xan-history', filtered.slice(0, 50));
  }, [animeId, episodeId]);

  return (
    <div className="space-y-6">
      {/* Video Player Area */}
      <div className="relative rounded-2xl overflow-hidden bg-black aspect-video shadow-2xl">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto">
              <Play className="w-10 h-10 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-white text-lg font-semibold">Episode {episodeId}</h3>
              <p className="text-zinc-400 text-sm mt-1">{anime?.title || 'Loading...'}</p>
              <p className="text-zinc-500 text-xs mt-2">Stream will load when available</p>
            </div>
          </div>
        </div>
      </div>

      {/* Episode Info */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">{anime?.title}</h2>
          <p className="text-zinc-400 text-sm">Episode {episodeId} of {anime?.episodes || '?'}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => { navigator.clipboard.writeText(window.location.href); showToast('Link copied!', 'success'); }}
            className="p-2.5 bg-zinc-800 rounded-lg text-zinc-300 hover:bg-zinc-700 transition-colors">
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Episode Navigation */}
      <div className="flex gap-2 flex-wrap">
        {anime?.episodes && Array.from({ length: Math.min(anime.episodes, 12) }, (_, i) => i + 1).map(ep => (
          <button key={ep} onClick={() => onNavigate('#/watch/' + animeId + '/' + ep)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${ep === episodeId ? 'bg-indigo-500 text-white' : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'}`}>
            Ep {ep}
          </button>
        ))}
      </div>

      {/* Anime Info */}
      {anime && (
        <div className="p-4 bg-zinc-800/50 rounded-xl border border-zinc-700/50">
          <h3 className="text-white font-semibold mb-2">{anime.title}</h3>
          <p className="text-zinc-400 text-sm line-clamp-3">{anime.description}</p>
          <button onClick={() => onNavigate('#/anime/' + anime.id)}
            className="mt-3 text-indigo-400 text-sm hover:text-indigo-300 transition-colors">
            View full details →
          </button>
        </div>
      )}
    </div>
  );
}

// Watchlist Page
function WatchlistPage({ onNavigate }: { onNavigate: (route: string) => void }) {
  const [watchlist, setWatchlist] = useState<Anime[]>(() => {
    if (typeof window === 'undefined') return [];
    return getStore<Anime[]>('xan-watchlist', []);
  });

  // Refresh watchlist on focus (in case it changed in another tab/view)
  useEffect(() => {
    const handleFocus = () => {
      setWatchlist(getStore<Anime[]>('xan-watchlist', []));
    };
    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white" style={{ fontFamily: "var(--font-instrument-serif), ui-serif, Georgia, serif" }}>My Watchlist</h1>
      {watchlist.length === 0 ? (
        <div className="text-center py-20 text-zinc-500">
          <BookmarkPlus className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg">Your watchlist is empty</p>
          <p className="text-sm mt-1">Browse anime and add some!</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {watchlist.map(a => (
            <AnimeCard key={a.id} anime={a} onClick={() => onNavigate('#/anime/' + a.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

// History Page
function HistoryPage({ onNavigate }: { onNavigate: (route: string) => void }) {
  const [historyAnime, setHistoryAnime] = useState<Anime[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const history = getStore<{ animeId: number; episodeId: number; timestamp: number }[]>('xan-history', []);
    const uniqueIds = [...new Set(history.map(h => h.animeId))].slice(0, 15);
    Promise.all(uniqueIds.map(id => api.getAnimeById(id).catch(() => null)))
      .then(results => { setHistoryAnime(results.filter(Boolean) as Anime[]); setLoading(false); })
      .catch(() => { setLoading(false); });
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white" style={{ fontFamily: "var(--font-instrument-serif), ui-serif, Georgia, serif" }}>Watch History</h1>
      {loading ? <SkeletonGrid /> : historyAnime.length === 0 ? (
        <div className="text-center py-20 text-zinc-500">
          <Clock className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg">No watch history yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {historyAnime.map(a => (
            <AnimeCard key={a.id} anime={a} onClick={() => onNavigate('#/anime/' + a.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

// Trending Page
function TrendingPage({ onNavigate }: { onNavigate: (route: string) => void }) {
  const [anime, setAnime] = useState<Anime[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getTop('bypopularity')
      .then(setAnime)
      .catch(() => showToast('Failed to load', 'error'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white" style={{ fontFamily: "var(--font-instrument-serif), ui-serif, Georgia, serif" }}>🔥 Trending Anime</h1>
      {loading ? <SkeletonGrid /> : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {anime.map(a => (
            <AnimeCard key={a.id} anime={a} onClick={() => onNavigate('#/anime/' + a.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

// =================== MAIN APP ===================

export default function XANApp() {
  const [route, setRoute] = useState('/');
  const [params, setParams] = useState<Record<string, string>>({});
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window === 'undefined') return 'dark';
    return (getStore<string>('xan-theme', 'dark')) as 'dark' | 'light';
  });
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Hash-based routing
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.slice(1) || '/';
      const [path, queryString] = hash.split('?');
      const p: Record<string, string> = {};
      if (queryString) {
        queryString.split('&').forEach(pair => {
          const [key, value] = pair.split('=');
          p[decodeURIComponent(key)] = decodeURIComponent(value || '');
        });
      }

      // Match routes
      if (path === '/') { setRoute('/'); setParams({}); }
      else if (path === '/trending') { setRoute('/trending'); setParams({}); }
      else if (path === '/search') { setRoute('/search'); setParams(p); }
      else if (path.startsWith('/anime/')) {
        const parts = path.split('/');
        setRoute('/anime/:id'); setParams({ id: parts[2], ...p });
      }
      else if (path.startsWith('/watch/')) {
        const parts = path.split('/');
        setRoute('/watch/:animeId/:episodeId'); setParams({ animeId: parts[2], episodeId: parts[3] || '1', ...p });
      }
      else if (path === '/history') { setRoute('/history'); setParams({}); }
      else if (path === '/watchlist') { setRoute('/watchlist'); setParams({}); }
      else { setRoute('/'); setParams({}); }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Theme: apply dark class on mount
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    setStore('xan-theme', next);
  };

  // Back to top
  useEffect(() => {
    const handleScroll = () => setShowBackToTop(window.scrollY > 400);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigate = (hashRoute: string) => {
    window.location.hash = hashRoute;
  };

  const navItems = [
    { icon: Home, label: 'Home', route: '/' },
    { icon: TrendingUp, label: 'Trending', route: '/trending' },
    { icon: Search, label: 'Search', route: '/search' },
    { icon: Clock, label: 'History', route: '/history' },
    { icon: BookmarkPlus, label: 'Watchlist', route: '/watchlist' },
  ];

  const isActive = (navRoute: string) => {
    if (navRoute === '/') return route === '/';
    return route === navRoute || (navRoute !== '/' && '/' + route.split('/')[1] === navRoute);
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark' : ''}`}>
      <div className="min-h-screen bg-zinc-950 text-white">
        {/* Header */}
        <header className="fixed top-0 left-0 right-0 h-16 bg-zinc-950/90 backdrop-blur-xl border-b border-zinc-800 z-50 flex items-center px-4 md:px-6">
          <div className="flex items-center gap-3 mr-4">
            <button className="md:hidden p-1.5 text-zinc-400 hover:text-white" onClick={() => setSidebarOpen(!sidebarOpen)}>
              <Film className="w-5 h-5" />
            </button>
            <a href="#/" className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent" style={{ fontFamily: "var(--font-instrument-serif), ui-serif, Georgia, serif" }}>
              XAN
            </a>
          </div>
          <div className="flex-1 max-w-md mx-auto hidden sm:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <input type="text" placeholder="Quick search..." onKeyDown={e => {
                if (e.key === 'Enter') { const q = (e.target as HTMLInputElement).value.trim(); if (q) navigate('#/search?q=' + encodeURIComponent(q)); }
              }} className="w-full pl-9 pr-4 py-2 bg-zinc-800/50 border border-zinc-700/50 rounded-full text-sm text-white placeholder:text-zinc-500 outline-none focus:border-indigo-500/50 transition-colors" />
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button onClick={toggleTheme} className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors">
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </header>

        {/* Sidebar - Desktop */}
        <nav className="hidden md:flex fixed top-16 left-0 bottom-0 w-[70px] bg-zinc-950 border-r border-zinc-800 z-40 flex-col items-center py-4 gap-1">
          {navItems.map(item => (
            <a key={item.route} href={'#' + item.route}
              className={`flex flex-col items-center py-3 px-2 w-full transition-colors
                ${isActive(item.route) ? 'text-indigo-400 bg-indigo-500/10 border-r-2 border-indigo-400' : 'text-zinc-500 hover:text-white hover:bg-zinc-800/50'}`}>
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] mt-1">{item.label}</span>
            </a>
          ))}
        </nav>

        {/* Mobile Sidebar Overlay */}
        {sidebarOpen && (
          <div className="md:hidden fixed inset-0 z-50" onClick={() => setSidebarOpen(false)}>
            <div className="absolute inset-0 bg-black/60" />
            <nav className="absolute left-0 top-0 bottom-0 w-56 bg-zinc-900 border-r border-zinc-800 p-4 pt-20" onClick={e => e.stopPropagation()}>
              {navItems.map(item => (
                <a key={item.route} href={'#' + item.route} onClick={() => setSidebarOpen(false)}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 transition-colors
                    ${isActive(item.route) ? 'text-indigo-400 bg-indigo-500/10' : 'text-zinc-300 hover:bg-zinc-800'}`}>
                  <item.icon className="w-5 h-5" />
                  <span className="text-sm">{item.label}</span>
                </a>
              ))}
            </nav>
          </div>
        )}

        {/* Main Content */}
        <main className="pt-16 md:pl-[70px] min-h-screen">
          <div className="p-4 md:p-8 max-w-7xl mx-auto pb-24 md:pb-8">
            {route === '/' && <HomePage onNavigate={navigate} />}
            {route === '/trending' && <TrendingPage onNavigate={navigate} />}
            {route === '/search' && <SearchPage onNavigate={navigate} />}
            {route === '/anime/:id' && params.id && <AnimeDetailPage animeId={parseInt(params.id)} onNavigate={navigate} />}
            {route === '/watch/:animeId/:episodeId' && params.animeId && <WatchPage animeId={parseInt(params.animeId)} episodeId={parseInt(params.episodeId || '1')} onNavigate={navigate} />}
            {route === '/history' && <HistoryPage onNavigate={navigate} />}
            {route === '/watchlist' && <WatchlistPage onNavigate={navigate} />}
          </div>

          {/* Footer */}
          <footer className="md:ml-[70px] border-t border-zinc-800 px-4 md:px-8 py-8 text-center text-zinc-500 text-sm">
            <span className="text-indigo-400 font-semibold" style={{ fontFamily: "var(--font-instrument-serif), ui-serif, Georgia, serif" }}>XAN</span>
            {' '}— Powered by Jikan API
          </footer>
        </main>

        {/* Mobile Bottom Nav */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-zinc-950/95 backdrop-blur-xl border-t border-zinc-800 z-50 flex items-center justify-around px-2">
          {navItems.slice(0, 4).map(item => (
            <a key={item.route} href={'#' + item.route}
              className={`flex flex-col items-center py-1.5 px-3 rounded-lg transition-colors
                ${isActive(item.route) ? 'text-indigo-400' : 'text-zinc-500'}`}>
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">{item.label}</span>
            </a>
          ))}
        </nav>

        {/* Back to Top */}
        <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className={`fixed bottom-20 md:bottom-8 right-4 p-3 bg-zinc-800 border border-zinc-700 rounded-full text-zinc-300 shadow-lg transition-all duration-300 z-40
            ${showBackToTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}>
          <ArrowUp className="w-4 h-4" />
        </button>

        {/* Toast Container */}
        <ToastContainer />
      </div>
    </div>
  );
}
