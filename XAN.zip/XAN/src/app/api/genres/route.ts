import { NextResponse } from 'next/server';

const JIKAN_API = 'https://api.jikan.moe/v4';
let lastRequest = 0;

async function rateLimitedFetch(url: string): Promise<any> {
    const now = Date.now();
    const wait = Math.max(0, 350 - (now - lastRequest));
    if (wait > 0) await new Promise(r => setTimeout(r, wait));
    lastRequest = Date.now();
    const response = await fetch(url);
    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
}

export async function GET() {
    try {
        const data = await rateLimitedFetch(`${JIKAN_API}/genres/anime`);
        return NextResponse.json(data.data || []);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
