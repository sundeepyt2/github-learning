import { NextRequest, NextResponse } from 'next/server';

const JIKAN_API = 'https://api.jikan.moe/v4';
const cache = new Map<string, { data: any; time: number }>();
const CACHE_DURATION = 3600000;

let lastRequest = 0;

async function rateLimitedFetch(url: string, params: Record<string, string> = {}): Promise<any> {
    const now = Date.now();
    const wait = Math.max(0, 350 - (now - lastRequest));
    if (wait > 0) await new Promise(r => setTimeout(r, wait));
    lastRequest = Date.now();

    const searchParams = new URLSearchParams(params);
    const fullUrl = `${url}?${searchParams.toString()}`;
    const response = await fetch(fullUrl, { next: { revalidate: 3600 } });
    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
}

const ADULT_GENRE_NAMES = new Set(['Hentai', 'Erotica']);
const ADULT_RATINGS = new Set(['Rx', 'R+']);

function transformAnime(anime: any) {
    const isAdult = ADULT_RATINGS.has(anime.rating) ||
        anime.genres?.some((g: any) => ADULT_GENRE_NAMES.has(g.name)) || false;

    return {
        id: anime.mal_id,
        title: anime.title || anime.title_english || 'Unknown',
        titleEnglish: anime.title_english || anime.title,
        image: anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url,
        smallImage: anime.images?.jpg?.image_url,
        description: (anime.synopsis || '').substring(0, 500),
        fullDescription: anime.synopsis || '',
        genre: anime.genres?.map((g: any) => g.name) || [],
        rating: anime.score || 0,
        year: anime.year || 'Unknown',
        status: anime.status || 'Unknown',
        episodes: anime.episodes || 0,
        type: anime.type || 'Unknown',
        aired: anime.aired?.string || 'Unknown',
        studios: anime.studios?.map((s: any) => s.name) || [],
        isAdult,
    };
}

export async function GET(request: NextRequest) {
    try {
        const cacheKey = 'popular';
        const cached = cache.get(cacheKey);
        if (cached && Date.now() - cached.time < CACHE_DURATION) {
            return NextResponse.json(cached.data);
        }
        const data = await rateLimitedFetch(`${JIKAN_API}/top/anime`, { filter: 'bypopularity', limit: '25' });
        const transformed = (data.data || []).map(transformAnime);
        cache.set(cacheKey, { data: transformed, time: Date.now() });
        return NextResponse.json(transformed);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
