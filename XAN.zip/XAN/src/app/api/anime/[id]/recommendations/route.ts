import { NextRequest, NextResponse } from 'next/server';

const JIKAN_API = 'https://api.jikan.moe/v4';
let lastRequest = 0;

async function rateLimitedFetch(url: string): Promise<any> {
    const now = Date.now();
    const wait = Math.max(0, 350 - (now - lastRequest));
    if (wait > 0) await new Promise(r => setTimeout(r, wait));
    lastRequest = Date.now();
    const response = await fetch(url);
    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const data = await rateLimitedFetch(`${JIKAN_API}/anime/${params.id}/recommendations`);
        const transformed = (data.data || []).map((item: any) => ({
            id: item.entry?.mal_id,
            title: item.entry?.title,
            image: item.entry?.images?.jpg?.large_image_url || item.entry?.images?.jpg?.image_url,
        })).filter((r: any) => r.id);
        return NextResponse.json(transformed);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
