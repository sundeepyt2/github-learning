import { NextRequest, NextResponse } from 'next/server';

const JIKAN_API = 'https://api.jikan.moe/v4';
let lastRequest = 0;

async function rateLimitedFetch(url: string): Promise<any> {
    const now = Date.now();
    const wait = Math.max(0, 350 - (now - lastRequest));
    if (wait > 0) await new Promise(r => setTimeout(r, wait));
    lastRequest = Date.now();
    const response = await fetch(url);
    if (!response.ok) throw new Error(`API error: ${response.status}`);
    return response.json();
}

const ADULT_GENRE_NAMES = new Set(['Hentai', 'Erotica']);
const ADULT_RATINGS = new Set(['Rx', 'R+']);

function transformAnime(anime: any) {
    const isAdult = ADULT_RATINGS.has(anime.rating) ||
        anime.genres?.some((g: any) => ADULT_GENRE_NAMES.has(g.name)) || false;
    return {
        id: anime.mal_id,
        title: anime.title || anime.title_english || 'Unknown',
        titleEnglish: anime.title_english || anime.title,
        image: anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url,
        smallImage: anime.images?.jpg?.image_url,
        description: (anime.synopsis || '').substring(0, 500),
        fullDescription: anime.synopsis || '',
        genre: anime.genres?.map((g: any) => g.name) || [],
        rating: anime.score || 0,
        year: anime.year || 'Unknown',
        status: anime.status || 'Unknown',
        episodes: anime.episodes || 0,
        type: anime.type || 'Unknown',
        aired: anime.aired?.string || 'Unknown',
        studios: anime.studios?.map((s: any) => s.name) || [],
        isAdult,
    };
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const data = await rateLimitedFetch(`${JIKAN_API}/anime/${params.id}`);
        return NextResponse.json(transformAnime(data.data));
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
