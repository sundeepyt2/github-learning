const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;
const JIKAN_API = 'https://api.jikan.moe/v4';

app.set('trust proxy', true);

const corsOptions = {
    origin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173',
    credentials: true
};
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.static('../frontend'));

const cache = {};
const CACHE_DURATION = 3600000;

const rateLimiters = new Map();
const RATE_LIMIT = { tokens: 3, interval: 1000, perMinute: 60 };
const minuteCounters = new Map();

function getRateLimiter(ip) {
    if (!rateLimiters.has(ip)) {
        rateLimiters.set(ip, { tokens: RATE_LIMIT.tokens, lastRefill: Date.now() });
    }
    return rateLimiters.get(ip);
}

function getMinuteCounter(ip) {
    const now = Date.now();
    if (!minuteCounters.has(ip)) {
        minuteCounters.set(ip, { count: 0, windowStart: now });
    }
    const c = minuteCounters.get(ip);
    if (now - c.windowStart > 60000) {
        c.count = 0;
        c.windowStart = now;
    }
    return c;
}

setInterval(() => {
    const now = Date.now();
    for (const [ip, entry] of rateLimiters) {
        if (now - entry.lastRefill > 300000) rateLimiters.delete(ip);
    }
    for (const [ip, entry] of minuteCounters) {
        if (now - entry.windowStart > 300000) minuteCounters.delete(ip);
    }
}, 300000);

async function rateLimitedFetch(url, params = {}, req) {
    const ip = req?.ip || req?.socket?.remoteAddress || 'unknown';
    const limiter = getRateLimiter(ip);
    const minute = getMinuteCounter(ip);

    if (minute.count >= RATE_LIMIT.perMinute) {
        const wait = 60000 - (Date.now() - minute.windowStart);
        if (wait > 0) await new Promise(r => setTimeout(r, wait));
        minute.count = 0;
        minute.windowStart = Date.now();
    }

    const now = Date.now();
    const elapsed = now - limiter.lastRefill;
    const tokensToAdd = Math.floor(elapsed / RATE_LIMIT.interval) * RATE_LIMIT.tokens;
    if (tokensToAdd > 0) {
        limiter.tokens = Math.min(RATE_LIMIT.tokens, limiter.tokens + tokensToAdd);
        limiter.lastRefill = now;
    }
    if (limiter.tokens < 1) {
        const waitTime = Math.max(0, RATE_LIMIT.interval - (now - limiter.lastRefill));
        await new Promise(r => setTimeout(r, waitTime));
        limiter.tokens = RATE_LIMIT.tokens;
        limiter.lastRefill = Date.now();
    }
    limiter.tokens--;
    minute.count++;

    const response = await axios.get(url, { params, timeout: 10000 });
    return response.data;
}

const ADULT_GENRE_NAMES = new Set(['Hentai', 'Erotica']);
const ADULT_RATINGS = new Set(['Rx', 'R+']);

function transformAnime(anime) {
    const isAdult = ADULT_RATINGS.has(anime.rating) ||
                   anime.genres?.some(g => ADULT_GENRE_NAMES.has(g.name)) ||
                   false;

    return {
        id: anime.mal_id,
        title: anime.title || anime.title_english || 'Unknown',
        titleEnglish: anime.title_english || anime.title,
        image: anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url,
        smallImage: anime.images?.jpg?.image_url,
        description: (anime.synopsis || '').substring(0, 500),
        fullDescription: anime.synopsis || '',
        genre: anime.genres?.map(g => g.name) || [],
        rating: anime.score || 0,
        year: anime.year || 'Unknown',
        status: anime.status || 'Unknown',
        episodes: anime.episodes || 0,
        type: anime.type || 'Unknown',
        aired: anime.aired?.string || 'Unknown',
        studios: anime.studios?.map(s => s.name) || [],
        isAdult,
        url: anime.url || ''
    };
}

app.get('/api/anime/:id/recommendations', async (req, res) => {
    try {
        const data = await rateLimitedFetch(`${JIKAN_API}/anime/${req.params.id}/recommendations`, {}, req);
        const transformed = (data.data || []).map(item => ({
            id: item.entry?.mal_id,
            title: item.entry?.title,
            image: item.entry?.images?.jpg?.large_image_url || item.entry?.images?.jpg?.image_url
        })).filter(r => r.id);
        res.json(transformed);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/anime/:id/characters', async (req, res) => {
    try {
        const data = await rateLimitedFetch(`${JIKAN_API}/anime/${req.params.id}/characters`, {}, req);
        const transformed = (data.data || []).map(c => ({
            id: c.character?.mal_id,
            name: c.character?.name,
            image: c.character?.images?.jpg?.image_url,
            role: c.role
        })).filter(c => c.id);
        res.json(transformed);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/anime', async (req, res) => {
    try {
        const cacheKey = 'popular';
        if (cache[cacheKey] && Date.now() - cache[cacheKey].time < CACHE_DURATION) {
            return res.json(cache[cacheKey].data);
        }
        const data = await rateLimitedFetch(`${JIKAN_API}/top/anime`, {
            filter: 'bypopularity', limit: 25
        }, req);
        const transformed = (data.data || []).map(transformAnime);
        cache[cacheKey] = { data: transformed, time: Date.now() };
        res.json(transformed);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/anime/:id', async (req, res) => {
    try {
        const data = await rateLimitedFetch(`${JIKAN_API}/anime/${req.params.id}`, {}, req);
        res.json(transformAnime(data.data));
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/search', async (req, res) => {
    try {
        const { q, page = 1, adult = 'false' } = req.query;
        const data = await rateLimitedFetch(`${JIKAN_API}/anime`, {
            q, page, limit: 25
        }, req);
        let results = (data.data || []).map(transformAnime);
        if (adult !== 'true') {
            results = results.filter(a => !a.isAdult);
        }
        res.json({ results, pagination: data.pagination });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/genres', async (req, res) => {
    try {
        const data = await rateLimitedFetch(`${JIKAN_API}/genres/anime`, {}, req);
        res.json(data.data || []);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/genre/:id', async (req, res) => {
    try {
        const { page = 1, adult = 'false' } = req.query;
        const data = await rateLimitedFetch(`${JIKAN_API}/anime`, {
            genres: req.params.id,
            page,
            limit: 25
        }, req);
        let results = (data.data || []).map(transformAnime);
        if (adult !== 'true') {
            results = results.filter(a => !a.isAdult);
        }
        res.json({ results, pagination: data.pagination });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/top', async (req, res) => {
    try {
        const { filter = 'bypopularity', adult = 'false' } = req.query;
        const data = await rateLimitedFetch(`${JIKAN_API}/top/anime`, {
            filter, limit: 25
        }, req);
        let results = (data.data || []).map(transformAnime);
        if (adult !== 'true') {
            results = results.filter(a => !a.isAdult);
        }
        res.json(results);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/random', async (req, res) => {
    try {
        const data = await rateLimitedFetch(`${JIKAN_API}/random/anime`, {}, req);
        res.json(transformAnime(data.data));
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    if (err.type === 'entity.parse.failed') {
        return res.status(400).json({ error: 'Malformed JSON body' });
    }
    res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
