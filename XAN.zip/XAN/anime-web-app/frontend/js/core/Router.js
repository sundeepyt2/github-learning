import EventBus from './EventBus.js';

const Router = {
    _routes: {},
    _currentRoute: null,
    _previousRoute: null,
    _ready: false,

    add(path, handler) {
        this._routes[path] = handler;
    },

    init() {
        window.addEventListener('hashchange', () => this._handleRoute());
        this._ready = true;
        this._handleRoute();
    },

    navigate(path) {
        window.location.hash = path;
    },

    back() {
        if (this._previousRoute) this.navigate(this._previousRoute);
        else this.navigate('/');
    },

    _handleRoute() {
        if (!this._ready) return;

        const hash = window.location.hash.slice(1) || '/';
        const [path, queryString] = hash.split('?');

        const params = {};
        if (queryString) {
            queryString.split('&').forEach(pair => {
                const [key, value] = pair.split('=');
                params[decodeURIComponent(key)] = decodeURIComponent(value || '');
            });
        }

        let matchedHandler = null;
        let pathParams = {};

        for (const [routePath, handler] of Object.entries(this._routes)) {
            const match = this._matchRoute(routePath, path);
            if (match) {
                matchedHandler = handler;
                pathParams = match;
                break;
            }
        }

        if (matchedHandler) {
            this._previousRoute = this._currentRoute;
            this._currentRoute = path;

            EventBus.emit('route:change', {
                path,
                params: { ...params, ...pathParams },
                previous: this._previousRoute
            });

            matchedHandler({ ...params, ...pathParams });
        } else {
            console.warn(`No route matched: ${path}. Redirecting to /`);
            if (path !== '/') this.navigate('/');
        }
    },

    _matchRoute(pattern, path) {
        const patternParts = pattern.split('/');
        const pathParts = path.split('/');

        if (patternParts.length !== pathParts.length) return null;

        const params = {};
        for (let i = 0; i < patternParts.length; i++) {
            if (patternParts[i].startsWith(':')) {
                params[patternParts[i].slice(1)] = pathParts[i];
            } else if (patternParts[i] !== pathParts[i]) {
                return null;
            }
        }
        return params;
    },

    getCurrent() {
        return this._currentRoute;
    }
};

export default Router;
