const KeyboardManager = {
    _handlers: new Map(),
    _enabled: true,
    _videoElement: null,
    _boundHandle: null,

    SHORTCUTS: {
        ' ': 'play/pause',
        'k': 'play/pause',
        'ArrowLeft': 'seek-back-5',
        'j': 'seek-back-5',
        'ArrowRight': 'seek-forward-5',
        'l': 'seek-forward-5',
        'ArrowUp': 'volume-up',
        'ArrowDown': 'volume-down',
        'm': 'mute',
        'f': 'fullscreen',
        'p': 'picture-in-picture',
        'c': 'captions',
        '0': 'seek-0',
        '1': 'seek-10',
        '2': 'seek-20',
        '3': 'seek-30',
        '4': 'seek-40',
        '5': 'seek-50',
        '6': 'seek-60',
        '7': 'seek-70',
        '8': 'seek-80',
        '9': 'seek-90',
        'Home': 'seek-start',
        'End': 'seek-end',
        '<': 'speed-down',
        '>': 'speed-up',
        ',': 'frame-back',
        '.': 'frame-forward',
        'Escape': 'exit-fullscreen',
        '?': 'show-shortcuts'
    },

    init(videoElement) {
        if (this._boundHandle) {
            document.removeEventListener('keydown', this._boundHandle);
        }
        this._videoElement = videoElement || null;
        this._boundHandle = (e) => this._handle(e);
        document.addEventListener('keydown', this._boundHandle);
    },

    destroy() {
        if (this._boundHandle) {
            document.removeEventListener('keydown', this._boundHandle);
            this._boundHandle = null;
        }
        this._handlers.clear();
    },

    _handle(e) {
        if (!this._enabled) return;
        const tag = e.target.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
        if (document.querySelector('[data-modal-active="true"]')) return;

        const key = e.key;
        const action = this.SHORTCUTS[key];

        if (action && this._handlers.has(action)) {
            e.preventDefault();
            this._handlers.get(action)(e);
        }
    },

    register(action, handler) {
        this._handlers.set(action, handler);
    },

    unregister(action) {
        this._handlers.delete(action);
    },

    setVideo(video) {
        this._videoElement = video;
    },

    enable() { this._enabled = true; },
    disable() { this._enabled = false; },

    showHelp() {
        const overlay = document.createElement('div');
        overlay.className = 'shortcuts-overlay';
        overlay.innerHTML = `
            <div class="shortcuts-panel">
                <h3>Keyboard Shortcuts</h3>
                <div class="shortcuts-grid">
                    <div class="shortcut-group">
                        <h4>Playback</h4>
                        <div class="shortcut-item"><kbd>Space</kbd> <span>Play/Pause</span></div>
                        <div class="shortcut-item"><kbd>K</kbd> <span>Play/Pause</span></div>
                        <div class="shortcut-item"><kbd>J</kbd> <span>Rewind 5s</span></div>
                        <div class="shortcut-item"><kbd>L</kbd> <span>Forward 5s</span></div>
                    </div>
                    <div class="shortcut-group">
                        <h4>Volume</h4>
                        <div class="shortcut-item"><kbd>Up</kbd> <span>Volume Up</span></div>
                        <div class="shortcut-item"><kbd>Down</kbd> <span>Volume Down</span></div>
                        <div class="shortcut-item"><kbd>M</kbd> <span>Mute</span></div>
                    </div>
                    <div class="shortcut-group">
                        <h4>Navigation</h4>
                        <div class="shortcut-item"><kbd>F</kbd> <span>Fullscreen</span></div>
                        <div class="shortcut-item"><kbd>P</kbd> <span>Picture-in-Picture</span></div>
                        <div class="shortcut-item"><kbd>C</kbd> <span>Captions</span></div>
                        <div class="shortcut-item"><kbd>0-9</kbd> <span>Seek to %</span></div>
                    </div>
                    <div class="shortcut-group">
                        <h4>Speed</h4>
                        <div class="shortcut-item"><kbd>&lt;</kbd> <span>Slower</span></div>
                        <div class="shortcut-item"><kbd>&gt;</kbd> <span>Faster</span></div>
                    </div>
                </div>
                <button class="btn-close" data-action="close">×</button>
            </div>
        `;
        document.body.appendChild(overlay);
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay || e.target.dataset.action === 'close') {
                overlay.remove();
            }
        });
    }
};

export default KeyboardManager;
