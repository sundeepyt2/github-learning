const Registry = {
    _components: {},
    _initialized: new Set(),
    _container: null,

    init(containerId = 'app') {
        this._container = document.getElementById(containerId);
    },

    register(name, component) {
        if (this._initialized.has(name)) {
            console.warn(`Re-registering "${name}" which is currently initialized. Call stop() first.`);
        }
        this._components[name] = component;
    },

    start(name, targetId) {
        const component = this._components[name];
        if (!component) { console.warn(`Component "${name}" not registered`); return; }

        if (this._initialized.has(name)) {
            this.stop(name);
        }

        const target = document.getElementById(targetId);
        if (!target) { console.warn(`Target "${targetId}" not found`); return; }

        if (component.init) component.init();
        if (component.render) target.innerHTML = component.render();
        if (component.mount) component.mount();

        this._initialized.add(name);
    },

    stop(name) {
        const component = this._components[name];
        if (!component || !this._initialized.has(name)) return;
        if (component.destroy) component.destroy();
        this._initialized.delete(name);
    },

    stopAll() {
        for (const name of [...this._initialized]) this.stop(name);
    },

    stopPageScoped(persistent) {
        const persistentSet = new Set(persistent);
        for (const name of [...this._initialized]) {
            if (!persistentSet.has(name)) this.stop(name);
        }
    },

    isInitialized(name) {
        return this._initialized.has(name);
    },

    get(name) {
        return this._components[name];
    }
};

export default Registry;
