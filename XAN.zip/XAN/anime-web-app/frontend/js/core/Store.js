import EventBus from './EventBus.js';

const Store = {
    _state: {},
    _key: 'anime-app-state',

    init() {
        const saved = localStorage.getItem(this._key);
        if (saved) {
            try { this._state = JSON.parse(saved); }
            catch (e) { this._state = {}; }
        }

        this._state = {
            theme: 'dark',
            adultEnabled: false,
            ageVerified: null,
            watchHistory: [],
            watchlist: [],
            lastWatched: null,
            searchHistory: [],
            playbackSpeed: 1,
            qualityLevel: -1,
            ...this._state
        };

        for (const key of Object.keys(this._state)) {
            EventBus.emit('store:change', { key, value: this._state[key] });
        }
    },

    get(key) {
        return this._state[key];
    },

    set(key, value) {
        this._state[key] = value;
        this._persist();
        EventBus.emit('store:change', { key, value });
    },

    update(key, updater) {
        const current = this._state[key];
        const next = updater(current === undefined ? null : current);
        this._state[key] = next;
        this._persist();
        EventBus.emit('store:change', { key, value: next });
    },

    push(key, item) {
        if (!Array.isArray(this._state[key])) this._state[key] = [];
        this._state[key].push(item);
        this._persist();
        EventBus.emit('store:change', { key, value: this._state[key] });
    },

    remove(key, predicate) {
        if (!Array.isArray(this._state[key])) return;
        this._state[key] = this._state[key].filter(item => !predicate(item));
        this._persist();
        EventBus.emit('store:change', { key, value: this._state[key] });
    },

    _persist() {
        try {
            localStorage.setItem(this._key, JSON.stringify(this._state));
        } catch (e) {
            if (e.name === 'QuotaExceededError') {
                for (const k of Object.keys(this._state)) {
                    if (Array.isArray(this._state[k]) && this._state[k].length > 20) {
                        this._state[k] = this._state[k].slice(-20);
                    }
                }
                try {
                    localStorage.setItem(this._key, JSON.stringify(this._state));
                } catch (e2) {
                    console.error('Store persist failed even after cleanup:', e2);
                }
            } else {
                console.error('Store persist error:', e);
            }
        }
    }
};

export default Store;
