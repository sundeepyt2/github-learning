import EventBus from './core/EventBus.js';
import Registry from './core/Registry.js';
import Router from './core/Router.js';
import Store from './core/Store.js';
import KeyboardManager from './core/KeyboardManager.js';

import Header from './components/Header.js';
import Sidebar from './components/Sidebar.js';
import AnimeGrid from './components/AnimeGrid.js';
import AnimeDetails from './components/AnimeDetails.js';
import SearchBar from './components/SearchBar.js';
import SearchResults from './components/SearchResults.js';
import SearchSuggestions from './components/SearchSuggestions.js';
import Pagination from './components/Pagination.js';
import GenreChips from './components/GenreChips.js';
import VideoPlayer from './components/VideoPlayer.js';
import ContinueWatching from './components/ContinueWatching.js';
import RecentlyWatched from './components/RecentlyWatched.js';
import WatchHistory from './components/WatchHistory.js';
import ThemeToggle from './components/ThemeToggle.js';
import AgeGate from './components/AgeGate.js';
import AdultToggle from './components/AdultToggle.js';
import FilterBar from './components/FilterBar.js';
import ShareButton from './components/ShareButton.js';
import BackToTop from './components/BackToTop.js';
import SkeletonLoader from './components/SkeletonLoader.js';
import HeroBanner from './components/HeroBanner.js';
import MobileNav from './components/MobileNav.js';
import Toast from './components/Toast.js';
import Footer from './components/Footer.js';

import JikanAPI from './api/jikan.js';
import AniPubAPI from './api/anipub.js';

const PERSISTENT_COMPONENTS = [
    'header', 'sidebar', 'footer', 'age-gate', 'back-to-top',
    'search-bar', 'search-suggestions', 'theme-toggle', 'adult-toggle',
    'skeleton-loader', 'share-button', 'mobile-nav', 'toast'
];

async function init() {
    Store.init();
    Registry.init('app');
    KeyboardManager.init();

    const theme = Store.get('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', theme);

    // Register all components
    Registry.register('header', Header);
    Registry.register('sidebar', Sidebar);
    Registry.register('anime-grid', AnimeGrid);
    Registry.register('anime-details', AnimeDetails);
    Registry.register('search-bar', SearchBar);
    Registry.register('search-results', SearchResults);
    Registry.register('search-suggestions', SearchSuggestions);
    Registry.register('pagination', Pagination);
    Registry.register('genre-chips', GenreChips);
    Registry.register('video-player', VideoPlayer);
    Registry.register('continue-watching', ContinueWatching);
    Registry.register('recently-watched', RecentlyWatched);
    Registry.register('watch-history', WatchHistory);
    Registry.register('theme-toggle', ThemeToggle);
    Registry.register('age-gate', AgeGate);
    Registry.register('adult-toggle', AdultToggle);
    Registry.register('filter-bar', FilterBar);
    Registry.register('share-button', ShareButton);
    Registry.register('back-to-top', BackToTop);
    Registry.register('skeleton-loader', SkeletonLoader);
    Registry.register('hero-banner', HeroBanner);
    Registry.register('mobile-nav', MobileNav);
    Registry.register('toast', Toast);
    Registry.register('footer', Footer);

    // Start persistent components
    Registry.start('header', 'header-container');
    Registry.start('sidebar', 'sidebar-container');
    Registry.start('footer', 'footer-container');
    Registry.start('age-gate', 'age-gate-container');
    Registry.start('back-to-top', 'back-to-top-container');
    Registry.start('search-bar', 'header-search-container');
    Registry.start('search-suggestions', 'header-search-container');
    Registry.start('theme-toggle', 'header-right-container');
    Registry.start('adult-toggle', 'header-right-container');
    Registry.start('skeleton-loader', 'skeleton-container');
    Registry.start('share-button', 'share-container');
    Registry.start('mobile-nav', 'mobile-nav-container');
    Registry.start('toast', 'toast-container');

    // Register routes
    Router.add('/', loadHomePage);
    Router.add('/trending', loadTrendingPage);
    Router.add('/search', loadSearchPage);
    Router.add('/anime/:id', loadAnimePage);
    Router.add('/watch/:animeId/:episodeId', loadWatchPage);
    Router.add('/history', loadHistoryPage);
    Router.add('/watchlist', loadWatchlistPage);

    Router.init();

    if (window.lucide) window.lucide.createIcons();

    console.log('XAN initialized');
}

async function loadHomePage() {
    Registry.stopPageScoped(PERSISTENT_COMPONENTS);

    const main = document.getElementById('main-content');
    main.innerHTML = `
        <div id="hero-container"></div>
        <div id="continue-watching-container"></div>
        <div id="recently-watched-container"></div>
        <div id="genres-container"></div>
        <div id="grid-container"></div>
        <div id="pagination-container"></div>
    `;

    Registry.start('hero-banner', 'hero-container');
    Registry.start('continue-watching', 'continue-watching-container');
    Registry.start('recently-watched', 'recently-watched-container');
    Registry.start('genre-chips', 'genres-container');
    Registry.start('anime-grid', 'grid-container');
    Registry.start('pagination', 'pagination-container');

    await new Promise(r => setTimeout(r, 0));
    EventBus.emit('loading:show', {});
    try {
        const anime = await JikanAPI.getPopular();
        EventBus.emit('anime:loaded', { anime });
    } catch (err) {
        EventBus.emit('notification:show', { message: 'Failed to load anime.', type: 'error' });
    } finally {
        EventBus.emit('loading:hide', {});
    }
}

async function loadTrendingPage() {
    Registry.stopPageScoped(PERSISTENT_COMPONENTS);

    const main = document.getElementById('main-content');
    main.innerHTML = `
        <h1 class="page-title" style="font-family:var(--font-display);font-size:var(--text-3xl);margin-bottom:var(--space-lg);">Trending Anime</h1>
        <div id="grid-container"></div>
        <div id="pagination-container"></div>
    `;

    Registry.start('anime-grid', 'grid-container');
    Registry.start('pagination', 'pagination-container');

    await new Promise(r => setTimeout(r, 0));
    EventBus.emit('loading:show', {});
    try {
        const anime = await JikanAPI.getTop('bypopularity', Store.get('adultEnabled'));
        EventBus.emit('anime:loaded', { anime });
    } catch (err) {
        EventBus.emit('notification:show', { message: 'Failed to load trending anime.', type: 'error' });
    } finally {
        EventBus.emit('loading:hide', {});
    }
}

async function loadSearchPage(params) {
    Registry.stopPageScoped(PERSISTENT_COMPONENTS);

    const query = params.q || '';
    const page = parseInt(params.page) || 1;

    const main = document.getElementById('main-content');
    main.innerHTML = `
        <h1 class="page-title" style="font-family:var(--font-display);font-size:var(--text-3xl);margin-bottom:var(--space-lg);">${query ? `Search: ${query}` : 'Browse Anime'}</h1>
        <div id="filter-container"></div>
        <div id="grid-container"></div>
        <div id="pagination-container"></div>
    `;

    Registry.start('filter-bar', 'filter-container');
    Registry.start('anime-grid', 'grid-container');
    Registry.start('pagination', 'pagination-container');

    if (query) {
        await new Promise(r => setTimeout(r, 0));
        EventBus.emit('loading:show', {});
        try {
            const results = await JikanAPI.search(query, page, Store.get('adultEnabled'));
            EventBus.emit('anime:loaded', { anime: results.results || [] });
            EventBus.emit('search:results', {
                results: results.results || [],
                total: results.pagination?.Items?.total || 0,
                page,
                totalPages: results.pagination?.last_visible_page || 1
            });
        } catch (err) {
            EventBus.emit('notification:show', { message: 'Search failed.', type: 'error' });
        } finally {
            EventBus.emit('loading:hide', {});
        }
    }
}

async function loadAnimePage(params) {
    Registry.stopPageScoped(PERSISTENT_COMPONENTS);

    const animeId = params.id;
    Store.set('currentAnimeId', animeId);

    const main = document.getElementById('main-content');
    main.innerHTML = `
        <div id="details-container"></div>
        <div id="video-container"></div>
        <div id="recommendations-container"></div>
    `;

    Registry.start('anime-details', 'details-container');
    Registry.start('video-player', 'video-container');

    await new Promise(r => setTimeout(r, 0));
    EventBus.emit('loading:show', {});
    try {
        const anime = await JikanAPI.getAnimeById(animeId);
        EventBus.emit('anime:loaded', { anime });
    } catch (err) {
        EventBus.emit('notification:show', { message: 'Failed to load anime.', type: 'error' });
    } finally {
        EventBus.emit('loading:hide', {});
    }
}

async function loadWatchPage(params) {
    Registry.stopPageScoped(PERSISTENT_COMPONENTS);

    const { animeId, episodeId } = params;
    Store.set('currentAnimeId', animeId);

    const main = document.getElementById('main-content');
    main.innerHTML = `
        <div id="video-container"></div>
        <div id="details-container"></div>
    `;

    Registry.start('video-player', 'video-container');
    Registry.start('anime-details', 'details-container');

    await new Promise(r => setTimeout(r, 0));
    EventBus.emit('loading:show', {});
    try {
        const anime = await JikanAPI.getAnimeById(animeId);
        EventBus.emit('anime:loaded', { anime });
        EventBus.emit('video:play', { animeId, episodeId: parseInt(episodeId) || 1, episodeNumber: parseInt(episodeId) || 1 });
    } catch (err) {
        EventBus.emit('notification:show', { message: 'Failed to load anime.', type: 'error' });
    } finally {
        EventBus.emit('loading:hide', {});
    }
}

async function loadHistoryPage() {
    Registry.stopPageScoped(PERSISTENT_COMPONENTS);

    const main = document.getElementById('main-content');
    main.innerHTML = `
        <h1 class="page-title" style="font-family:var(--font-display);font-size:var(--text-3xl);margin-bottom:var(--space-lg);">Watch History</h1>
        <div id="history-container"></div>
    `;

    Registry.start('watch-history', 'history-container');
}

async function loadWatchlistPage() {
    Registry.stopPageScoped(PERSISTENT_COMPONENTS);

    const main = document.getElementById('main-content');
    const watchlist = Store.get('watchlist') || [];

    main.innerHTML = `
        <h1 class="page-title" style="font-family:var(--font-display);font-size:var(--text-3xl);margin-bottom:var(--space-lg);">My Watchlist</h1>
        <div id="watchlist-container">
            ${watchlist.length === 0
                ? '<p class="empty-state" style="color:var(--text-muted);text-align:center;padding:var(--space-2xl);">Your watchlist is empty. Browse anime and add some!</p>'
                : '<div id="grid-container"></div>'}
        </div>
    `;

    if (watchlist.length > 0) {
        Registry.start('anime-grid', 'grid-container');
        await new Promise(r => setTimeout(r, 0));
        EventBus.emit('anime:loaded', { anime: watchlist });
    }
}

document.addEventListener('DOMContentLoaded', init);
