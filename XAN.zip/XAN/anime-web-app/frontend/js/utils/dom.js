const DOM = {
    $(selector, parent = document) {
        return parent.querySelector(selector);
    },

    $$(selector, parent = document) {
        return [...parent.querySelectorAll(selector)];
    },

    create(tag, attrs = {}, children = []) {
        const el = document.createElement(tag);
        for (const [key, value] of Object.entries(attrs)) {
            if (key === 'className') el.className = value;
            else if (key === 'dataset') Object.assign(el.dataset, value);
            else if (key.startsWith('on')) el.addEventListener(key.slice(2).toLowerCase(), value);
            else el.setAttribute(key, value);
        }
        for (const child of children) {
            if (typeof child === 'string') el.appendChild(document.createTextNode(child));
            else if (child) el.appendChild(child);
        }
        return el;
    },

    empty(el) {
        while (el.firstChild) el.removeChild(el.firstChild);
    },

    show(el) { el.style.display = ''; },
    hide(el) { el.style.display = 'none'; },

    toggle(el) {
        el.style.display = el.style.display === 'none' ? '' : 'none';
    },

    addClass(el, ...classes) { el.classList.add(...classes); },
    removeClass(el, ...classes) { el.classList.remove(...classes); },
    toggleClass(el, cls) { el.classList.toggle(cls); },

    on(el, event, handler, options) {
        el.addEventListener(event, handler, options);
        return () => el.removeEventListener(event, handler, options);
    }
};

export default DOM;
