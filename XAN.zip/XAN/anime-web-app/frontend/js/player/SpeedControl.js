import KeyboardManager from '../core/KeyboardManager.js';
import Store from '../core/Store.js';
import EventBus from '../core/EventBus.js';

const SpeedControl = {
    SPEEDS: [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2],
    _video: null,
    _currentSpeed: 1,
    _registered: false,

    init(videoElement) {
        this._video = videoElement;

        const saved = Store.get('playbackSpeed');
        if (saved) this.setSpeed(parseFloat(saved));

        if (!this._registered) {
            KeyboardManager.register('speed-down', () => this.decrease());
            KeyboardManager.register('speed-up', () => this.increase());
            this._registered = true;
        }
    },

    destroy() {
        if (this._registered) {
            KeyboardManager.unregister('speed-down');
            KeyboardManager.unregister('speed-up');
            this._registered = false;
        }
    },

    _findSpeedIndex(rate) {
        return this.SPEEDS.findIndex(s => Math.abs(s - rate) < 0.01);
    },

    _clampedIndex() {
        let idx = this._findSpeedIndex(this._currentSpeed);
        if (idx === -1) {
            let nearest = 0, minDiff = Infinity;
            this.SPEEDS.forEach((s, i) => {
                const diff = Math.abs(s - this._currentSpeed);
                if (diff < minDiff) { minDiff = diff; nearest = i; }
            });
            idx = nearest;
            this.setSpeed(this.SPEEDS[idx]);
        }
        return idx;
    },

    setSpeed(rate) {
        if (!this._video) return;
        this._video.playbackRate = rate;
        this._currentSpeed = rate;
        Store.set('playbackSpeed', rate);
        EventBus.emit('player:speed-changed', { speed: rate });
    },

    getSpeed() {
        return this._currentSpeed;
    },

    increase() {
        const idx = this._clampedIndex();
        if (idx < this.SPEEDS.length - 1) {
            this.setSpeed(this.SPEEDS[idx + 1]);
        }
    },

    decrease() {
        const idx = this._clampedIndex();
        if (idx > 0) {
            this.setSpeed(this.SPEEDS[idx - 1]);
        }
    },

    reset() {
        this.setSpeed(1);
    }
};

export default SpeedControl;
