import AniPubAPI from '../api/anipub.js';
import EventBus from '../core/EventBus.js';

const StreamManager = {
    SOURCES: [
        {
            name: 'AniPub',
            getStream: async (animeId, episodeNumber) => {
                try {
                    const data = await AniPubAPI.getStreamingLinks(animeId);

                    const extractUrl = (raw) => {
                        if (!raw) return null;
                        if (raw.includes('src=')) {
                            try {
                                const u = new URL(raw, 'http://placeholder');
                                const src = u.searchParams.get('src');
                                return src || raw;
                            } catch {
                                return raw.split('src=')[1] || raw;
                            }
                        }
                        return raw;
                    };

                    let epUrl = null;
                    if (data?.local) {
                        if (episodeNumber === 1 && data.local.link) {
                            epUrl = extractUrl(data.local.link);
                        } else if (data.local.ep && Array.isArray(data.local.ep)) {
                            const epIndex = episodeNumber - 2;
                            if (epIndex >= 0 && epIndex < data.local.ep.length) {
                                epUrl = extractUrl(data.local.ep[epIndex]?.link);
                            }
                        }
                    }
                    return epUrl;
                } catch (err) {
                    console.warn('AniPub stream extraction failed:', err);
                    return null;
                }
            }
        }
    ],

    _currentSource: null,

    async getStream(animeId, episodeNumber) {
        for (const source of this.SOURCES) {
            try {
                const url = await source.getStream(animeId, episodeNumber);
                if (url) {
                    this._currentSource = source.name;
                    EventBus.emit('stream:source-changed', { source: source.name });
                    return { url, source: source.name };
                }
            } catch (err) {
                console.warn(`Source ${source.name} failed:`, err.message);
                continue;
            }
        }
        throw new Error('All stream sources failed');
    },

    async getFallbackStream(animeId, episodeNumber, failedSource) {
        const remainingSources = this.SOURCES.filter(s => s.name !== failedSource);

        for (const source of remainingSources) {
            try {
                const url = await source.getStream(animeId, episodeNumber);
                if (url) {
                    this._currentSource = source.name;
                    EventBus.emit('stream:source-changed', { source: source.name });
                    return { url, source: source.name };
                }
            } catch (err) {
                continue;
            }
        }
        return null;
    },

    getCurrentSource() {
        return this._currentSource;
    }
};

export default StreamManager;
