import Hls from 'hls.js';
import EventBus from '../core/EventBus.js';
import Store from '../core/Store.js';

const HLSPlayer = {
    _hls: null,
    _video: null,
    _currentLevel: -1,

    init(videoElement) {
        this._video = videoElement;
    },

    async load(url) {
        if (this._hls) this._hls.destroy();

        if (Hls.isSupported()) {
            this._hls = new Hls({
                startLevel: -1,
                capLevelToPlayerSize: true,
                maxBufferLength: 30,
                maxMaxBufferLength: 60
            });

            this._hls.loadSource(url);
            this._hls.attachMedia(this._video);

            this._hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                EventBus.emit('player:qualities-loaded', {
                    levels: this.getQualities()
                });

                const saved = Store.get('qualityLevel');
                if (saved !== null) this.setQuality(saved);

                this._video.play().catch(() => {});
            });

            this._hls.on(Hls.Events.ERROR, (event, data) => {
                if (data.fatal) this._handleFatalError(data);
            });

        } else if (this._video.canPlayType('application/vnd.apple.mpegurl')) {
            this._video.src = url;
            this._video.addEventListener('loadedmetadata', () => {
                this._video.play().catch(() => {});
            });
        } else {
            EventBus.emit('player:fatal-error', {
                error: { message: 'HLS not supported in this browser' }
            });
        }
    },

    _handleFatalError(data) {
        switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
                this._hls.startLoad();
                break;
            case Hls.ErrorTypes.MEDIA_ERROR:
                this._hls.recoverMediaError();
                break;
            default:
                EventBus.emit('player:fatal-error', { error: data });
                break;
        }
    },

    getQualities() {
        if (!this._hls) return [];
        return this._hls.levels.map((level, index) => ({
            index,
            height: level.height,
            width: level.width,
            bitrate: level.bitrate,
            label: level.height + 'p'
        }));
    },

    setQuality(levelIndex) {
        if (!this._hls) return;
        this._hls.currentLevel = levelIndex;
        this._currentLevel = levelIndex;
        Store.set('qualityLevel', levelIndex);
        EventBus.emit('player:quality-changed', { level: levelIndex });
    },

    getQuality() {
        return this._currentLevel;
    },

    destroy() {
        if (this._hls) {
            this._hls.destroy();
            this._hls = null;
        }
    }
};

export default HLSPlayer;
