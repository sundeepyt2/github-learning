import EventBus from '../core/EventBus.js';

const ProgressTracker = {
    STORAGE_KEY: 'anime-progress',
    SAVE_INTERVAL: 5000,
    COMPLETION_THRESHOLD: 0.9,
    _video: null,
    _animeId: null,
    _episodeId: null,
    _saveTimer: null,
    _completionHandled: false,
    _onTimeUpdateBound: null,
    _onBeforeUnloadBound: null,
    _onVisibilityBound: null,

    init(video, animeId, episodeId) {
        this.destroy();

        this._video = video;
        this._animeId = animeId;
        this._episodeId = episodeId;
        this._completionHandled = false;

        this._onTimeUpdateBound = () => this._onTimeUpdate();
        this._onBeforeUnloadBound = () => this._save();
        this._onVisibilityBound = () => { if (document.hidden) this._save(); };

        this._video.addEventListener('timeupdate', this._onTimeUpdateBound);
        window.addEventListener('beforeunload', this._onBeforeUnloadBound);
        document.addEventListener('visibilitychange', this._onVisibilityBound);
    },

    destroy() {
        if (this._video && this._onTimeUpdateBound) {
            this._video.removeEventListener('timeupdate', this._onTimeUpdateBound);
        }
        if (this._onBeforeUnloadBound) {
            window.removeEventListener('beforeunload', this._onBeforeUnloadBound);
        }
        if (this._onVisibilityBound) {
            document.removeEventListener('visibilitychange', this._onVisibilityBound);
        }
        if (this._saveTimer) {
            clearTimeout(this._saveTimer);
            this._saveTimer = null;
        }
        this._video = null;
        this._animeId = null;
        this._episodeId = null;
        this._onTimeUpdateBound = null;
        this._onBeforeUnloadBound = null;
        this._onVisibilityBound = null;
    },

    _onTimeUpdate() {
        if (!this._video || !this._video.duration) return;

        if (!this._saveTimer) {
            this._saveTimer = setTimeout(() => {
                this._save();
                this._saveTimer = null;
            }, this.SAVE_INTERVAL);
        }

        if (!this._completionHandled && this._isComplete()) {
            this._completionHandled = true;
            this._markCompleted();
        }
    },

    restore() {
        const all = this._getAll();
        return all[`${this._animeId}:${this._episodeId}`] || null;
    },

    _save() {
        if (!this._video || !this._video.duration) return;

        const all = this._getAll();
        const key = `${this._animeId}:${this._episodeId}`;

        all[key] = {
            currentTime: this._video.currentTime,
            duration: this._video.duration,
            percentage: Math.round((this._video.currentTime / this._video.duration) * 100),
            timestamp: Date.now(),
            animeId: this._animeId,
            episodeId: this._episodeId
        };

        const entries = Object.entries(all);
        try {
            if (entries.length > 50) {
                entries.sort((a, b) => b[1].timestamp - a[1].timestamp);
                localStorage.setItem(this.STORAGE_KEY, JSON.stringify(Object.fromEntries(entries.slice(0, 50))));
            } else {
                localStorage.setItem(this.STORAGE_KEY, JSON.stringify(all));
            }
        } catch (e) {
            console.error('ProgressTracker save failed (quota?):', e);
        }

        EventBus.emit('progress:saved', { animeId: this._animeId, episodeId: this._episodeId });
    },

    _isComplete() {
        if (!this._video || !this._video.duration) return false;
        return (this._video.currentTime / this._video.duration) > this.COMPLETION_THRESHOLD;
    },

    _markCompleted() {
        const all = this._getAll();
        const key = `${this._animeId}:${this._episodeId}`;
        delete all[key];
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(all));
        } catch (e) {
            console.error('ProgressTracker mark-completed save failed:', e);
        }
        EventBus.emit('progress:completed', { animeId: this._animeId, episodeId: this._episodeId });
    },

    _getAll() {
        const data = localStorage.getItem(this.STORAGE_KEY);
        return data ? JSON.parse(data) : {};
    },

    getContinueWatchingList() {
        const all = this._getAll();
        return Object.values(all)
            .filter(item => item.percentage < this.COMPLETION_THRESHOLD * 100)
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, 20);
    }
};

export default ProgressTracker;
