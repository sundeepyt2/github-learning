import EventBus from '../core/EventBus.js';

const FilterBar = {
    name: 'filter-bar',

    render() {
        return `
            <div class="filter-bar" id="filter-bar-inner">
                <div class="filter-bar__group">
                    <span class="filter-bar__label">Type:</span>
                    <select class="filter-bar__select" id="filter-type">
                        <option value="">All</option>
                        <option value="TV">TV</option>
                        <option value="Movie">Movie</option>
                        <option value="OVA">OVA</option>
                        <option value="Special">Special</option>
                    </select>
                </div>
                <div class="filter-bar__group">
                    <span class="filter-bar__label">Year:</span>
                    <select class="filter-bar__select" id="filter-year">
                        <option value="">All</option>
                        <option value="2024">2024</option>
                        <option value="2023">2023</option>
                        <option value="2022">2022</option>
                        <option value="2021">2021</option>
                        <option value="2020">2020</option>
                        <option value="2019">2019</option>
                        <option value="2018">2018</option>
                    </select>
                </div>
                <div class="filter-bar__group">
                    <span class="filter-bar__label">Season:</span>
                    <select class="filter-bar__select" id="filter-season">
                        <option value="">All</option>
                        <option value="winter">Winter</option>
                        <option value="spring">Spring</option>
                        <option value="summer">Summer</option>
                        <option value="fall">Fall</option>
                    </select>
                </div>
                <div class="filter-bar__group">
                    <span class="filter-bar__label">Status:</span>
                    <select class="filter-bar__select" id="filter-status">
                        <option value="">All</option>
                        <option value="Airing">Airing</option>
                        <option value="Complete">Complete</option>
                        <option value="Upcoming">Upcoming</option>
                    </select>
                </div>
            </div>
        `;
    },

    mount() {
        const filters = ['filter-type', 'filter-year', 'filter-season', 'filter-status'];
        filters.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.addEventListener('change', () => {
                    const filters = {
                        type: document.getElementById('filter-type')?.value || '',
                        year: document.getElementById('filter-year')?.value || '',
                        season: document.getElementById('filter-season')?.value || '',
                        status: document.getElementById('filter-status')?.value || ''
                    };
                    EventBus.emit('filter:change', { filters });
                });
            }
        });
    },

    destroy() {}
};

export default FilterBar;
