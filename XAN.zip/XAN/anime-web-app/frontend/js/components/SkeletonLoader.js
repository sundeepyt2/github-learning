import EventBus from '../core/EventBus.js';

const SkeletonLoader = {
    name: 'skeleton-loader',
    _unsubs: [],

    init() {
        this._unsubs.push(
            EventBus.on('loading:show', () => this._show()),
            EventBus.on('loading:hide', () => this._hide())
        );
    },

    render() {
        return `<div id="skeleton-loader-inner"></div>`;
    },

    renderGrid() {
        let cards = '';
        for (let i = 0; i < 12; i++) {
            cards += `
                <div class="skeleton-card">
                    <div class="skeleton-card__image skeleton"></div>
                    <div class="skeleton-card__text">
                        <div class="skeleton-card__title skeleton"></div>
                        <div class="skeleton-card__meta skeleton"></div>
                    </div>
                </div>
            `;
        }
        return `<div class="skeleton-grid">${cards}</div>`;
    },

    _show() {
        const container = document.getElementById('skeleton-loader-inner');
        if (container) container.innerHTML = this.renderGrid();
    },

    _hide() {
        const container = document.getElementById('skeleton-loader-inner');
        if (container) container.innerHTML = '';
    },

    mount() {},

    destroy() {
        this._unsubs.forEach(unsub => { if (unsub) unsub(); });
        this._unsubs = [];
    }
};

export default SkeletonLoader;
