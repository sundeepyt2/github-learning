import EventBus from '../core/EventBus.js';
import JikanAPI from '../api/jikan.js';
import Helpers from '../utils/helpers.js';

const SearchSuggestions = {
    name: 'search-suggestions',
    _visible: false,

    render() {
        return `<div class="search-suggestions" id="search-suggestions" style="display:none;"></div>`;
    },

    mount() {
        const input = document.getElementById('search-input');
        if (!input) return;

        const debouncedSearch = Helpers.debounce(async (query) => {
            if (query.length < 2) {
                this._hide();
                return;
            }
            try {
                const results = await JikanAPI.search(query, 1, false);
                this._show(results.results || []);
            } catch (err) {
                this._hide();
            }
        }, 300);

        input.addEventListener('input', (e) => {
            debouncedSearch(e.target.value.trim());
        });

        input.addEventListener('blur', () => {
            setTimeout(() => this._hide(), 200);
        });

        input.addEventListener('focus', (e) => {
            if (e.target.value.trim().length >= 2) {
                debouncedSearch(e.target.value.trim());
            }
        });

        document.addEventListener('click', (e) => {
            if (!e.target.closest('.header__search')) {
                this._hide();
            }
        });
    },

    _show(results) {
        const container = document.getElementById('search-suggestions');
        if (!container || results.length === 0) return;

        container.innerHTML = results.slice(0, 5).map(anime => `
            <div class="search-suggestions__item" data-anime-id="${anime.id}">
                <img class="search-suggestions__image" src="${anime.smallImage || anime.image || ''}" alt="" loading="lazy">
                <div>
                    <div class="search-suggestions__title">${Helpers.escapeHtml(anime.title)}</div>
                    <div class="search-suggestions__type">${anime.type || ''} ${anime.year || ''}</div>
                </div>
            </div>
        `).join('');

        container.style.display = 'block';
        this._visible = true;

        container.querySelectorAll('.search-suggestions__item').forEach(item => {
            item.addEventListener('click', () => {
                const id = item.dataset.animeId;
                if (id) window.location.hash = `#/anime/${id}`;
                this._hide();
            });
        });
    },

    _hide() {
        const container = document.getElementById('search-suggestions');
        if (container) container.style.display = 'none';
        this._visible = false;
    },

    destroy() {
        this._hide();
    }
};

export default SearchSuggestions;
