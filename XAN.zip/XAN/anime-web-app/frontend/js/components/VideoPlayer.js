import EventBus from '../core/EventBus.js';
import Store from '../core/Store.js';
import KeyboardManager from '../core/KeyboardManager.js';
import HLSPlayer from '../player/HLSPlayer.js';
import StreamManager from '../player/StreamManager.js';
import SpeedControl from '../player/SpeedControl.js';
import ProgressTracker from '../player/ProgressTracker.js';

const VideoPlayer = {
    name: 'video-player',
    _animeId: null,
    _episodeNumber: null,
    _autoNextTimer: null,
    _qualities: [],
    _unsubs: [],

    init() {
        this._unsubs.push(
            EventBus.on('video:play', (data) => this._playEpisode(data)),
            EventBus.on('video:next', (data) => this._playEpisode(data)),
            EventBus.on('player:qualities-loaded', (data) => {
                this._qualities = data.levels || [];
                this._renderQualityOptions();
            }),
            EventBus.on('player:fatal-error', (data) => {
                EventBus.emit('notification:show', {
                    message: `Playback error: ${data.error?.message || 'Unknown error'}`,
                    type: 'error'
                });
            }),
            EventBus.on('player:speed-changed', (data) => {
                const label = document.getElementById('speed-label');
                if (label) label.textContent = data.speed + 'x';
            })
        );
    },

    render() {
        return `
            <div class="video-player" id="video-player-inner">
                <div class="video-player__container">
                    <video class="video-player__video" id="video-element" controls playsinline></video>
                </div>
                <div class="video-player__controls" id="video-controls">
                    <span class="speed-control__label" id="speed-label">1x</span>
                    <div id="quality-selector"></div>
                </div>
            </div>
        `;
    },

    async _playEpisode(data) {
        const video = document.getElementById('video-element');
        if (!video) return;

        this._animeId = data.animeId || Store.get('currentAnimeId');
        this._episodeNumber = data.episodeNumber || 1;

        if (this._autoNextTimer) {
            clearTimeout(this._autoNextTimer);
            this._autoNextTimer = null;
        }

        try {
            const stream = await StreamManager.getStream(this._animeId, this._episodeNumber);
            if (stream?.url) {
                await HLSPlayer.init(video);
                await HLSPlayer.load(stream.url);
                KeyboardManager.setVideo(video);
                SpeedControl.init(video);
                ProgressTracker.init(video, this._animeId, this._episodeNumber);

                // Restore progress
                const progress = ProgressTracker.restore();
                if (progress?.currentTime && progress.currentTime > 5) {
                    video.currentTime = progress.currentTime;
                }

                // Track end for auto-next
                video.addEventListener('ended', () => this._onEpisodeEnd(), { once: true });

                // Add to history
                Store.update('watchHistory', (history) => {
                    const h = history || [];
                    const filtered = h.filter(item => !(item.animeId === this._animeId && item.episodeId === this._episodeNumber));
                    filtered.unshift({
                        animeId: this._animeId,
                        episodeId: this._episodeNumber,
                        timestamp: Date.now()
                    });
                    return filtered.slice(0, 50);
                });

                EventBus.emit('history:add', { animeId: this._animeId, episodeId: this._episodeNumber });
            }
        } catch (err) {
            EventBus.emit('notification:show', {
                message: 'Failed to load stream. Try again later.',
                type: 'error'
            });
        }
    },

    _onEpisodeEnd() {
        const nextEp = this._episodeNumber + 1;
        const container = document.getElementById('video-player-inner');
        if (!container) return;

        let countdown = 5;
        const countdownEl = document.createElement('div');
        countdownEl.className = 'video-player__auto-next';
        countdownEl.innerHTML = `
            <span>Next episode in <span class="video-player__auto-next-countdown" id="auto-next-countdown">${countdown}</span>s</span>
            <button class="anime-details__btn anime-details__btn--secondary" id="cancel-auto-next">Cancel</button>
        `;
        container.appendChild(countdownEl);

        this._autoNextTimer = setInterval(() => {
            countdown--;
            const cd = document.getElementById('auto-next-countdown');
            if (cd) cd.textContent = countdown;
            if (countdown <= 0) {
                clearInterval(this._autoNextTimer);
                this._autoNextTimer = null;
                EventBus.emit('video:next', { episodeId: nextEp, episodeNumber: nextEp });
            }
        }, 1000);

        const cancelBtn = document.getElementById('cancel-auto-next');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                clearInterval(this._autoNextTimer);
                this._autoNextTimer = null;
                countdownEl.remove();
            });
        }
    },

    _renderQualityOptions() {
        const selector = document.getElementById('quality-selector');
        if (!selector || this._qualities.length === 0) return;

        const currentQuality = HLSPlayer.getQuality();
        selector.innerHTML = `
            <select class="video-player__quality" id="quality-select">
                <option value="-1" ${currentQuality === -1 ? 'selected' : ''}>Auto</option>
                ${this._qualities.map(q => `
                    <option value="${q.index}" ${currentQuality === q.index ? 'selected' : ''}>${q.label}</option>
                `).join('')}
            </select>
        `;

        document.getElementById('quality-select')?.addEventListener('change', (e) => {
            HLSPlayer.setQuality(parseInt(e.target.value));
        });
    },

    mount() {},

    destroy() {
        this._unsubs.forEach(unsub => { if (unsub) unsub(); });
        this._unsubs = [];
        if (this._autoNextTimer) {
            clearTimeout(this._autoNextTimer);
            this._autoNextTimer = null;
        }
        HLSPlayer.destroy();
        SpeedControl.destroy();
        ProgressTracker.destroy();
    }
};

export default VideoPlayer;
