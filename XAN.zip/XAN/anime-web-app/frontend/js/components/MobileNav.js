import EventBus from '../core/EventBus.js';

const MobileNav = {
    name: 'mobile-nav',
    _unsub: null,

    render() {
        return `
            <nav class="mobile-nav" id="mobile-nav-inner">
                <a href="#/" class="mobile-nav__link" data-route="/">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    <span>Home</span>
                </a>
                <a href="#/search" class="mobile-nav__link" data-route="/search">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    <span>Search</span>
                </a>
                <a href="#/history" class="mobile-nav__link" data-route="/history">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    <span>History</span>
                </a>
                <a href="#/watchlist" class="mobile-nav__link" data-route="/watchlist">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
                    <span>Watchlist</span>
                </a>
            </nav>
        `;
    },

    mount() {
        this._updateActive();
        this._unsub = EventBus.on('route:change', () => this._updateActive());
    },

    _updateActive() {
        const route = window.location.hash.slice(1) || '/';
        document.querySelectorAll('.mobile-nav__link').forEach(link => {
            if (link.dataset.route === route || (link.dataset.route !== '/' && route.startsWith(link.dataset.route))) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    },

    destroy() {
        if (this._unsub) this._unsub();
    }
};

export default MobileNav;
