import EventBus from '../core/EventBus.js';
import Router from '../core/Router.js';
import Helpers from '../utils/helpers.js';

const AnimeCard = {
    name: 'anime-card',

    render(anime, progress = null) {
        const progressHtml = progress ? `
            <div class="anime-card__progress">
                <div class="anime-card__progress-bar" style="width: ${progress}%"></div>
            </div>
        ` : '';

        const badgeHtml = anime.type && anime.type !== 'TV' ?
            `<span class="anime-card__badge">${anime.type}</span>` : '';

        return `
            <div class="anime-card" data-anime-id="${anime.id}">
                ${badgeHtml}
                <img class="anime-card__image" src="${anime.image || ''}" alt="${Helpers.escapeHtml(anime.title)}" loading="lazy"
                     onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                <div class="anime-card__image anime-card__image--placeholder" style="display:none">🎬</div>
                <div class="anime-card__info">
                    <div class="anime-card__title" title="${Helpers.escapeHtml(anime.title)}">${Helpers.escapeHtml(anime.title)}</div>
                    <div class="anime-card__meta">
                        ${anime.rating ? `<span class="anime-card__rating">★ ${anime.rating}</span>` : ''}
                        <span>${anime.type || ''}</span>
                    </div>
                </div>
                ${progressHtml}
            </div>
        `;
    },

    bindEvents(container) {
        container.addEventListener('click', (e) => {
            const card = e.target.closest('.anime-card');
            if (!card) return;
            const animeId = card.dataset.animeId;
            if (animeId) {
                EventBus.emit('anime:select', { animeId });
                Router.navigate(`/anime/${animeId}`);
            }
        });
    }
};

export default AnimeCard;
