import EventBus from '../core/EventBus.js';
import AnimeCard from './AnimeCard.js';

const SearchResults = {
    name: 'search-results',
    _results: [],
    _unsub: null,

    init() {
        this._unsub = EventBus.on('anime:loaded', (data) => {
            if (Array.isArray(data.anime)) {
                this._results = data.anime;
                this._renderResults();
            }
        });
    },

    render() {
        return `
            <div class="search-results" id="search-results-inner"></div>
        `;
    },

    _renderResults() {
        const container = document.getElementById('search-results-inner');
        if (!container) return;

        if (this._results.length === 0) {
            container.innerHTML = '<div class="anime-grid__empty">No results found</div>';
            return;
        }

        container.innerHTML = `<div class="anime-grid">${this._results.map(a => AnimeCard.render(a)).join('')}</div>`;
        AnimeCard.bindEvents(container);
    },

    mount() {},

    destroy() {
        if (this._unsub) this._unsub();
        this._results = [];
    }
};

export default SearchResults;
