import EventBus from '../core/EventBus.js';
import Router from '../core/Router.js';
import Store from '../core/Store.js';
import JikanAPI from '../api/jikan.js';
import AnimeCard from './AnimeCard.js';
import Helpers from '../utils/helpers.js';

const AnimeDetails = {
    name: 'anime-details',
    _anime: null,
    _characters: [],
    _recommendations: [],
    _unsub: null,

    init() {
        this._unsub = EventBus.on('anime:loaded', (data) => {
            if (Array.isArray(data.anime)) return;
            this._anime = data.anime;
            this._loadExtra();
            this._renderDetails();
        });
    },

    render() {
        return `<div class="anime-details" id="anime-details-inner"></div>`;
    },

    async _loadExtra() {
        if (!this._anime || !this._anime.id) return;
        try {
            const [characters, recommendations] = await Promise.allSettled([
                JikanAPI.getCharacters(this._anime.id),
                JikanAPI.getRecommendations(this._anime.id)
            ]);
            if (characters.status === 'fulfilled') this._characters = characters.value || [];
            if (recommendations.status === 'fulfilled') this._recommendations = recommendations.value || [];
            this._renderDetails();
        } catch (err) {
            console.warn('Failed to load extra data:', err);
        }
    },

    _renderDetails() {
        const container = document.getElementById('anime-details-inner');
        if (!container || !this._anime) return;

        const anime = this._anime;
        const isInWatchlist = (Store.get('watchlist') || []).some(a => a.id === anime.id);

        let episodesHtml = '';
        if (anime.episodes && anime.episodes > 0) {
            let btns = '';
            for (let i = 1; i <= Math.min(anime.episodes, 24); i++) {
                btns += `<button class="anime-details__episode-btn" data-episode="${i}">E${i}</button>`;
            }
            if (anime.episodes > 24) {
                btns += `<span class="anime-details__episode-btn" style="pointer-events:none;">+${anime.episodes - 24}</span>`;
            }
            episodesHtml = `
                <div class="anime-details__episodes">
                    <h3 class="anime-details__episodes-title">Episodes</h3>
                    <div class="anime-details__episode-list">${btns}</div>
                </div>
            `;
        }

        let charactersHtml = '';
        if (this._characters.length > 0) {
            const chars = this._characters.slice(0, 8).map(c => `
                <div class="anime-details__character">
                    <img src="${c.image || ''}" alt="${Helpers.escapeHtml(c.name)}" loading="lazy"
                         onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2280%22 height=%2280%22><rect fill=%22%231a1a1a%22 width=%2280%22 height=%2280%22/></svg>'">
                    <div class="anime-details__character-name">${Helpers.escapeHtml(c.name)}</div>
                </div>
            `).join('');
            charactersHtml = `
                <div class="anime-details__characters">
                    <h3 class="anime-details__characters-title">Characters</h3>
                    <div class="anime-details__characters-grid">${chars}</div>
                </div>
            `;
        }

        let recsHtml = '';
        if (this._recommendations.length > 0) {
            const recs = this._recommendations.slice(0, 6).map(r => AnimeCard.render(r)).join('');
            recsHtml = `
                <div class="anime-details__recommendations">
                    <h3 class="anime-details__recommendations-title">Recommendations</h3>
                    <div class="anime-details__recommendations-grid">${recs}</div>
                </div>
            `;
        }

        container.innerHTML = `
            <div class="anime-details__poster">
                <img src="${anime.image || ''}" alt="${Helpers.escapeHtml(anime.title)}" loading="lazy">
            </div>
            <div class="anime-details__body">
                <h1 class="anime-details__title">${Helpers.escapeHtml(anime.title)}</h1>
                <div class="anime-details__meta">
                    ${anime.rating ? `<span class="anime-details__tag anime-details__tag--accent">★ ${anime.rating}</span>` : ''}
                    ${anime.type ? `<span class="anime-details__tag">${anime.type}</span>` : ''}
                    ${anime.year && anime.year !== 'Unknown' ? `<span class="anime-details__tag">${anime.year}</span>` : ''}
                    ${anime.status ? `<span class="anime-details__tag">${anime.status}</span>` : ''}
                </div>
                <p class="anime-details__description">${anime.fullDescription || anime.description || 'No description available.'}</p>
                <div class="anime-details__info-grid">
                    <div class="anime-details__info-item">
                        <span class="anime-details__info-label">Episodes</span>
                        <span class="anime-details__info-value">${anime.episodes || 'Unknown'}</span>
                    </div>
                    <div class="anime-details__info-item">
                        <span class="anime-details__info-label">Status</span>
                        <span class="anime-details__info-value">${anime.status || 'Unknown'}</span>
                    </div>
                    <div class="anime-details__info-item">
                        <span class="anime-details__info-label">Aired</span>
                        <span class="anime-details__info-value">${anime.aired || 'Unknown'}</span>
                    </div>
                    <div class="anime-details__info-item">
                        <span class="anime-details__info-label">Studios</span>
                        <span class="anime-details__info-value">${anime.studios?.join(', ') || 'Unknown'}</span>
                    </div>
                </div>
                <div class="anime-details__actions">
                    <button class="anime-details__btn anime-details__btn--primary" id="play-first-episode">
                        ▶ Watch Now
                    </button>
                    <button class="anime-details__btn anime-details__btn--secondary" id="toggle-watchlist">
                        ${isInWatchlist ? '♥ In Watchlist' : '♡ Add to Watchlist'}
                    </button>
                </div>
                ${episodesHtml}
                ${charactersHtml}
                ${recsHtml}
            </div>
        `;

        // Bind events
        const playBtn = document.getElementById('play-first-episode');
        if (playBtn) {
            playBtn.addEventListener('click', () => {
                EventBus.emit('video:play', { episodeId: 1, episodeNumber: 1 });
                Router.navigate(`/watch/${anime.id}/1`);
            });
        }

        const watchlistBtn = document.getElementById('toggle-watchlist');
        if (watchlistBtn) {
            watchlistBtn.addEventListener('click', () => {
                const watchlist = Store.get('watchlist') || [];
                const idx = watchlist.findIndex(a => a.id === anime.id);
                if (idx >= 0) {
                    watchlist.splice(idx, 1);
                    watchlistBtn.innerHTML = '♡ Add to Watchlist';
                    EventBus.emit('notification:show', { message: 'Removed from watchlist', type: 'info' });
                } else {
                    watchlist.push(anime);
                    watchlistBtn.innerHTML = '♥ In Watchlist';
                    EventBus.emit('notification:show', { message: 'Added to watchlist', type: 'success' });
                }
                Store.set('watchlist', watchlist);
            });
        }

        // Episode buttons
        container.querySelectorAll('.anime-details__episode-btn[data-episode]').forEach(btn => {
            btn.addEventListener('click', () => {
                const ep = parseInt(btn.dataset.episode);
                EventBus.emit('video:play', { episodeId: ep, episodeNumber: ep });
                Router.navigate(`/watch/${anime.id}/${ep}`);
            });
        });

        // Recommendation card clicks
        const recGrid = container.querySelector('.anime-details__recommendations-grid');
        if (recGrid) AnimeCard.bindEvents(recGrid);
    },

    mount() {},

    destroy() {
        if (this._unsub) this._unsub();
        this._anime = null;
        this._characters = [];
        this._recommendations = [];
    }
};

export default AnimeDetails;
