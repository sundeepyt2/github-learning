const Footer = {
    name: 'footer',

    render() {
        return `
            <footer class="footer">
                <div class="footer__content">
                    <div class="footer__brand">XAN</div>
                    <div class="footer__links">
                        <a href="#/" class="footer__link">Home</a>
                        <a href="#/trending" class="footer__link">Trending</a>
                        <a href="#/search" class="footer__link">Search</a>
                    </div>
                    <div style="color:var(--text-muted);font-size:var(--text-xs);">
                        Powered by Jikan API & AniPub
                    </div>
                </div>
            </footer>
        `;
    },

    mount() {},
    destroy() {}
};

export default Footer;
