import EventBus from '../core/EventBus.js';
import Router from '../core/Router.js';
import ProgressTracker from '../player/ProgressTracker.js';
import AnimeCard from './AnimeCard.js';

const ContinueWatching = {
    name: 'continue-watching',
    _unsub: null,

    init() {
        this._unsub = EventBus.on('progress:saved', () => this._renderList());
    },

    render() {
        return `
            <div class="continue-watching" id="continue-watching-inner">
                <h2 class="continue-watching__title">Continue Watching</h2>
                <div class="continue-watching__list" id="continue-watching-list"></div>
            </div>
        `;
    },

    _renderList() {
        const list = document.getElementById('continue-watching-list');
        if (!list) return;

        const items = ProgressTracker.getContinueWatchingList();
        if (items.length === 0) {
            const container = document.getElementById('continue-watching-inner');
            if (container) container.style.display = 'none';
            return;
        }

        const container = document.getElementById('continue-watching-inner');
        if (container) container.style.display = '';

        list.innerHTML = items.map(item => `
            <div class="continue-watching__item" data-anime-id="${item.animeId}" data-episode="${item.episodeId}">
                <div class="anime-card">
                    <div class="anime-card__image anime-card__image--placeholder" style="aspect-ratio:16/9;display:flex;">▶</div>
                    <div class="anime-card__info">
                        <div class="anime-card__title">Episode ${item.episodeId}</div>
                        <div class="anime-card__meta"><span>${item.percentage}% watched</span></div>
                    </div>
                    <div class="continue-watching__progress">
                        <div class="continue-watching__progress-bar" style="width:${item.percentage}%"></div>
                    </div>
                </div>
            </div>
        `).join('');

        list.querySelectorAll('.continue-watching__item').forEach(item => {
            item.addEventListener('click', () => {
                const animeId = item.dataset.animeId;
                const episode = item.dataset.episode;
                if (animeId) Router.navigate(`/watch/${animeId}/${episode}`);
            });
        });
    },

    mount() {
        this._renderList();
    },

    destroy() {
        if (this._unsub) this._unsub();
    }
};

export default ContinueWatching;
