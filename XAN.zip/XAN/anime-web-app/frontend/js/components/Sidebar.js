import EventBus from '../core/EventBus.js';
import Router from '../core/Router.js';

const Sidebar = {
    name: 'sidebar',

    render() {
        return `
            <nav class="sidebar">
                <div class="sidebar__nav">
                    <a href="#/" class="sidebar__link" data-route="/">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                        <span>Home</span>
                    </a>
                    <a href="#/trending" class="sidebar__link" data-route="/trending">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
                        <span>Trending</span>
                    </a>
                    <a href="#/search" class="sidebar__link" data-route="/search">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                        <span>Search</span>
                    </a>
                    <a href="#/history" class="sidebar__link" data-route="/history">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        <span>History</span>
                    </a>
                    <a href="#/watchlist" class="sidebar__link" data-route="/watchlist">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
                        <span>Watchlist</span>
                    </a>
                </div>
            </nav>
        `;
    },

    mount() {
        this._updateActive();
        this._unsub = EventBus.on('route:change', () => this._updateActive());
    },

    _updateActive() {
        const route = window.location.hash.slice(1) || '/';
        document.querySelectorAll('.sidebar__link').forEach(link => {
            const linkRoute = link.dataset.route;
            if (linkRoute === route || (linkRoute !== '/' && route.startsWith(linkRoute))) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    },

    destroy() {
        if (this._unsub) this._unsub();
    }
};

export default Sidebar;
