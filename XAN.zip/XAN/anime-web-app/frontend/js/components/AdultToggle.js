import EventBus from '../core/EventBus.js';
import Store from '../core/Store.js';

const AdultToggle = {
    name: 'adult-toggle',
    _unsub: null,

    render() {
        const enabled = Store.get('adultEnabled') || false;
        return `
            <button class="header__btn" id="adult-toggle-btn" title="Toggle adult content">
                ${enabled
                    ? '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>'
                    : '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>'
                }
            </button>
        `;
    },

    mount() {
        const btn = document.getElementById('adult-toggle-btn');
        if (!btn) return;

        btn.addEventListener('click', () => {
            const ageVerified = Store.get('ageVerified');
            if (!ageVerified) {
                EventBus.emit('notification:show', {
                    message: 'Please verify your age first.',
                    type: 'warning'
                });
                return;
            }

            const current = Store.get('adultEnabled') || false;
            Store.set('adultEnabled', !current);
            EventBus.emit('adult:toggle', { enabled: !current });

            // Re-render
            btn.outerHTML = this.render();
            this.mount();
        });
    },

    destroy() {
        if (this._unsub) this._unsub();
    }
};

export default AdultToggle;
