import EventBus from '../core/EventBus.js';
import AnimeCard from './AnimeCard.js';
import SkeletonLoader from './SkeletonLoader.js';

const AnimeGrid = {
    name: 'anime-grid',
    _anime: [],
    _unsub: null,

    init() {
        this._unsub = EventBus.on('anime:loaded', (data) => {
            this._anime = data.anime || [];
            this._renderAnime();
        });
    },

    render() {
        return `
            <div class="anime-grid" id="anime-grid-inner">
                ${SkeletonLoader.renderGrid()}
            </div>
        `;
    },

    _renderAnime() {
        const container = document.getElementById('anime-grid-inner');
        if (!container) return;

        if (this._anime.length === 0) {
            container.innerHTML = '<div class="anime-grid__empty">No anime found</div>';
            return;
        }

        container.innerHTML = this._anime.map(anime => AnimeCard.render(anime)).join('');
        AnimeCard.bindEvents(container);
    },

    mount() {
        if (this._anime.length > 0) {
            this._renderAnime();
        }
    },

    destroy() {
        if (this._unsub) this._unsub();
        this._anime = [];
    }
};

export default AnimeGrid;
