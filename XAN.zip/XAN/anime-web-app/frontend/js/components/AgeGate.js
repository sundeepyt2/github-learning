import EventBus from '../core/EventBus.js';
import Store from '../core/Store.js';

const AgeGate = {
    name: 'age-gate',

    render() {
        const verified = Store.get('ageVerified');
        if (verified === true) return '';

        return `
            <div class="age-gate" id="age-gate">
                <div class="age-gate__panel">
                    <h2 class="age-gate__title">Age Verification</h2>
                    <p class="age-gate__text">
                        This section may contain content intended for mature audiences.
                        Are you 18 years or older?
                    </p>
                    <div class="age-gate__actions">
                        <button class="age-gate__btn age-gate__btn--confirm" id="age-confirm">Yes, I am 18+</button>
                        <button class="age-gate__btn age-gate__btn--deny" id="age-deny">No</button>
                    </div>
                </div>
            </div>
        `;
    },

    mount() {
        const confirmBtn = document.getElementById('age-confirm');
        const denyBtn = document.getElementById('age-deny');

        if (confirmBtn) {
            confirmBtn.addEventListener('click', () => {
                Store.set('ageVerified', true);
                EventBus.emit('adult:verify', { verified: true, enabled: Store.get('adultEnabled') });
                const gate = document.getElementById('age-gate');
                if (gate) gate.remove();
            });
        }

        if (denyBtn) {
            denyBtn.addEventListener('click', () => {
                Store.set('ageVerified', false);
                Store.set('adultEnabled', false);
                EventBus.emit('adult:verify', { verified: false, enabled: false });
                const gate = document.getElementById('age-gate');
                if (gate) gate.remove();
            });
        }
    },

    destroy() {}
};

export default AgeGate;
