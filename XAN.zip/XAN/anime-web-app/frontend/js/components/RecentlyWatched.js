import EventBus from '../core/EventBus.js';
import Router from '../core/Router.js';
import Store from '../core/Store.js';
import JikanAPI from '../api/jikan.js';
import AnimeCard from './AnimeCard.js';

const RecentlyWatched = {
    name: 'recently-watched',
    _anime: [],
    _unsub: null,

    init() {
        this._unsub = EventBus.on('history:add', () => this._loadRecent());
    },

    render() {
        return `
            <div class="recently-watched" id="recently-watched-inner">
                <h2 class="recently-watched__title">Recently Watched</h2>
                <div class="recently-watched__list" id="recently-watched-list"></div>
            </div>
        `;
    },

    async _loadRecent() {
        const history = Store.get('watchHistory') || [];
        if (history.length === 0) {
            const container = document.getElementById('recently-watched-inner');
            if (container) container.style.display = 'none';
            return;
        }

        const container = document.getElementById('recently-watched-inner');
        if (container) container.style.display = '';

        const list = document.getElementById('recently-watched-list');
        if (!list) return;

        // Load anime data for recent history
        const recentIds = [...new Set(history.map(h => h.animeId))].slice(0, 10);
        const animeData = [];
        for (const id of recentIds) {
            try {
                const anime = await JikanAPI.getAnimeById(id);
                animeData.push(anime);
            } catch (err) {
                // Skip failed loads
            }
        }
        this._anime = animeData;

        list.innerHTML = animeData.map(a => `
            <div class="recently-watched__item">
                ${AnimeCard.render(a)}
            </div>
        `).join('');

        AnimeCard.bindEvents(list);
    },

    mount() {
        this._loadRecent();
    },

    destroy() {
        if (this._unsub) this._unsub();
        this._anime = [];
    }
};

export default RecentlyWatched;
