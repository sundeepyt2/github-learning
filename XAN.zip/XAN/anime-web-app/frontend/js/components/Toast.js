import EventBus from '../core/EventBus.js';

const Toast = {
    name: 'toast',
    _unsub: null,

    init() {
        this._unsub = EventBus.on('notification:show', (data) => this._show(data));
    },

    render() {
        return '';
    },

    _show({ message, type = 'info' }) {
        const container = document.getElementById('toast-container');
        if (!container) return;
        const toast = document.createElement('div');
        toast.className = `toast toast--${type}`;
        toast.textContent = message;
        container.appendChild(toast);
        setTimeout(() => toast.classList.add('toast--visible'), 10);
        setTimeout(() => {
            toast.classList.remove('toast--visible');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    },

    destroy() {
        if (this._unsub) this._unsub();
    }
};

export default Toast;
