const BackToTop = {
    name: 'back-to-top',

    render() {
        return `
            <div class="back-to-top" id="back-to-top">
                <button class="back-to-top__btn" title="Back to top">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>
                </button>
            </div>
        `;
    },

    mount() {
        const btn = document.querySelector('#back-to-top .back-to-top__btn');
        const container = document.getElementById('back-to-top');
        if (!btn || !container) return;

        btn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                container.classList.add('back-to-top--visible');
            } else {
                container.classList.remove('back-to-top--visible');
            }
        });
    },

    destroy() {}
};

export default BackToTop;
