import EventBus from '../core/EventBus.js';

const Pagination = {
    name: 'pagination',
    _currentPage: 1,
    _totalPages: 1,
    _unsub: null,

    init() {
        this._unsub = EventBus.on('search:results', (data) => {
            this._currentPage = data.page || 1;
            this._totalPages = data.totalPages || 1;
            this._renderPagination();
        });
    },

    render() {
        return `<div class="pagination" id="pagination-inner"></div>`;
    },

    _renderPagination() {
        const container = document.getElementById('pagination-inner');
        if (!container || this._totalPages <= 1) {
            if (container) container.innerHTML = '';
            return;
        }

        let html = '';

        // Previous button
        html += `<button class="pagination__btn ${this._currentPage <= 1 ? 'pagination__btn--disabled' : ''}"
                    data-page="${this._currentPage - 1}" ${this._currentPage <= 1 ? 'disabled' : ''}>‹</button>`;

        // Page numbers
        const maxVisible = 5;
        let start = Math.max(1, this._currentPage - Math.floor(maxVisible / 2));
        let end = Math.min(this._totalPages, start + maxVisible - 1);
        if (end - start < maxVisible - 1) start = Math.max(1, end - maxVisible + 1);

        if (start > 1) {
            html += `<button class="pagination__btn" data-page="1">1</button>`;
            if (start > 2) html += `<span class="pagination__info">...</span>`;
        }

        for (let i = start; i <= end; i++) {
            html += `<button class="pagination__btn ${i === this._currentPage ? 'pagination__btn--active' : ''}" data-page="${i}">${i}</button>`;
        }

        if (end < this._totalPages) {
            if (end < this._totalPages - 1) html += `<span class="pagination__info">...</span>`;
            html += `<button class="pagination__btn" data-page="${this._totalPages}">${this._totalPages}</button>`;
        }

        // Next button
        html += `<button class="pagination__btn ${this._currentPage >= this._totalPages ? 'pagination__btn--disabled' : ''}"
                    data-page="${this._currentPage + 1}" ${this._currentPage >= this._totalPages ? 'disabled' : ''}>›</button>`;

        container.innerHTML = html;

        container.querySelectorAll('.pagination__btn:not(.pagination__btn--disabled)').forEach(btn => {
            btn.addEventListener('click', () => {
                const page = parseInt(btn.dataset.page);
                if (page && page !== this._currentPage) {
                    EventBus.emit('page:change', { page, totalPages: this._totalPages });
                }
            });
        });
    },

    mount() {},

    destroy() {
        if (this._unsub) this._unsub();
    }
};

export default Pagination;
