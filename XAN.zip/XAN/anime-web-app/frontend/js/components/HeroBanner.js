import EventBus from '../core/EventBus.js';
import Router from '../core/Router.js';
import JikanAPI from '../api/jikan.js';
import Helpers from '../utils/helpers.js';

const HeroBanner = {
    name: 'hero-banner',
    _anime: null,

    init() {
        this._loadHero();
    },

    async _loadHero() {
        try {
            const anime = await JikanAPI.getRandom();
            this._anime = anime;
            this._renderHero();
        } catch (err) {
            console.warn('Failed to load hero banner:', err);
        }
    },

    render() {
        return `<div id="hero-banner-inner" style="min-height:300px;"></div>`;
    },

    _renderHero() {
        const container = document.getElementById('hero-banner-inner');
        if (!container || !this._anime) return;

        const anime = this._anime;
        container.innerHTML = `
            <div style="
                position:relative;
                border-radius:var(--radius-lg);
                overflow:hidden;
                background:linear-gradient(to right, var(--bg-primary) 40%, transparent),
                            url('${anime.image || ''}') center/cover no-repeat;
                min-height:300px;
                display:flex;
                align-items:center;
                padding:var(--space-2xl);
                margin-bottom:var(--space-lg);
            ">
                <div style="max-width:500px;">
                    <h1 style="font-family:var(--font-display);font-size:var(--text-3xl);margin-bottom:var(--space-sm);line-height:1.2;">
                        ${Helpers.escapeHtml(anime.title)}
                    </h1>
                    <p style="color:var(--text-secondary);margin-bottom:var(--space-lg);line-height:1.6;">
                        ${Helpers.truncate(anime.description || anime.fullDescription || '', 200)}
                    </p>
                    <div style="display:flex;gap:var(--space-sm);">
                        <button class="anime-details__btn anime-details__btn--primary" id="hero-play-btn">
                            ▶ Watch Now
                        </button>
                        <button class="anime-details__btn anime-details__btn--secondary" id="hero-details-btn">
                            Details
                        </button>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('hero-play-btn')?.addEventListener('click', () => {
            Router.navigate(`/watch/${anime.id}/1`);
        });

        document.getElementById('hero-details-btn')?.addEventListener('click', () => {
            Router.navigate(`/anime/${anime.id}`);
        });
    },

    mount() {},

    destroy() {
        this._anime = null;
    }
};

export default HeroBanner;
