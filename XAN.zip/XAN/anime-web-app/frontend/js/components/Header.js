import EventBus from '../core/EventBus.js';
import Router from '../core/Router.js';
import Store from '../core/Store.js';

const Header = {
    name: 'header',

    render() {
        return `
            <header class="header">
                <div class="header__left">
                    <a href="#/" class="header__logo">
                        <span class="header__logo-text">XAN</span>
                    </a>
                </div>
                <div class="header__center" id="header-search-container"></div>
                <div class="header__right" id="header-right-container"></div>
            </header>
        `;
    },

    mount() {
        // Header is structural, sub-components mount into its containers
    },

    destroy() {}
};

export default Header;
