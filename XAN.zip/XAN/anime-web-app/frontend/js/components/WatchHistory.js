import Store from '../core/Store.js';
import JikanAPI from '../api/jikan.js';
import AnimeCard from './AnimeCard.js';
import Helpers from '../utils/helpers.js';

const WatchHistory = {
    name: 'watch-history',

    render() {
        return `<div id="watch-history-inner"></div>`;
    },

    async mount() {
        const container = document.getElementById('watch-history-inner');
        if (!container) return;

        const history = Store.get('watchHistory') || [];
        if (history.length === 0) {
            container.innerHTML = '<p class="empty-state">No watch history yet.</p>';
            return;
        }

        container.innerHTML = '<div class="anime-grid" id="history-grid"></div>';
        const grid = document.getElementById('history-grid');

        const animeData = [];
        const seenIds = new Set();
        for (const item of history) {
            if (seenIds.has(item.animeId)) continue;
            seenIds.add(item.animeId);
            try {
                const anime = await JikanAPI.getAnimeById(item.animeId);
                animeData.push(anime);
            } catch (err) {
                // Skip failed loads
            }
        }

        grid.innerHTML = animeData.map(a => AnimeCard.render(a)).join('');
        AnimeCard.bindEvents(grid);
    },

    destroy() {}
};

export default WatchHistory;
