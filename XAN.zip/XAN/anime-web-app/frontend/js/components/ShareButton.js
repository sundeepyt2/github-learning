const ShareButton = {
    name: 'share-button',

    render() {
        return `
            <div class="share-button" id="share-button-inner">
                <button class="share-button__btn" id="share-btn" title="Share">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
                </button>
            </div>
        `;
    },

    mount() {
        const btn = document.getElementById('share-btn');
        if (!btn) return;

        btn.addEventListener('click', async () => {
            const url = window.location.href;
            try {
                await navigator.clipboard.writeText(url);
                // Create a quick toast
                const toast = document.createElement('div');
                toast.className = 'toast toast--success toast--visible';
                toast.textContent = 'Link copied!';
                const container = document.getElementById('toast-container');
                if (container) {
                    container.appendChild(toast);
                    setTimeout(() => toast.remove(), 2000);
                }
            } catch (err) {
                console.warn('Failed to copy:', err);
            }
        });
    },

    destroy() {}
};

export default ShareButton;
