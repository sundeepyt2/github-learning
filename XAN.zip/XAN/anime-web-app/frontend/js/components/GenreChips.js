import EventBus from '../core/EventBus.js';
import JikanAPI from '../api/jikan.js';

const GenreChips = {
    name: 'genre-chips',
    _genres: [],
    _activeGenre: null,
    _unsub: null,

    init() {
        this._loadGenres();
    },

    async _loadGenres() {
        try {
            const genres = await JikanAPI.getGenres();
            this._genres = (genres || []).slice(0, 20);
            this._renderChips();
        } catch (err) {
            console.warn('Failed to load genres:', err);
        }
    },

    render() {
        return `<div class="genre-chips" id="genre-chips-inner"></div>`;
    },

    _renderChips() {
        const container = document.getElementById('genre-chips-inner');
        if (!container) return;

        container.innerHTML = this._genres.map(g => `
            <button class="genre-chips__chip ${this._activeGenre === g.mal_id ? 'genre-chips__chip--active' : ''}"
                    data-genre-id="${g.mal_id}" data-genre-name="${g.name}">
                ${g.name}
            </button>
        `).join('');

        container.querySelectorAll('.genre-chips__chip').forEach(chip => {
            chip.addEventListener('click', () => {
                const genreId = parseInt(chip.dataset.genreId);
                const genreName = chip.dataset.genreName;

                if (this._activeGenre === genreId) {
                    this._activeGenre = null;
                    chip.classList.remove('genre-chips__chip--active');
                } else {
                    container.querySelectorAll('.genre-chips__chip').forEach(c => c.classList.remove('genre-chips__chip--active'));
                    this._activeGenre = genreId;
                    chip.classList.add('genre-chips__chip--active');
                }

                EventBus.emit('genre:select', { genreId: this._activeGenre, genreName });
            });
        });
    },

    mount() {},

    destroy() {
        if (this._unsub) this._unsub();
        this._genres = [];
        this._activeGenre = null;
    }
};

export default GenreChips;
