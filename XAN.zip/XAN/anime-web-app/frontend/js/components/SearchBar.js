import EventBus from '../core/EventBus.js';
import Helpers from '../utils/helpers.js';

const SearchBar = {
    name: 'search-bar',
    _unsub: null,

    render() {
        return `
            <div class="header__search" id="search-bar">
                <svg class="header__search-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                <input type="text" id="search-input" placeholder="Search anime..." autocomplete="off">
            </div>
        `;
    },

    mount() {
        const input = document.getElementById('search-input');
        if (!input) return;

        const debouncedSearch = Helpers.debounce((query) => {
            if (query.length >= 2) {
                EventBus.emit('search:query', { query, page: 1 });
            }
        }, 300);

        input.addEventListener('input', (e) => {
            debouncedSearch(e.target.value.trim());
        });

        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                const query = e.target.value.trim();
                if (query) {
                    window.location.hash = `#/search?q=${encodeURIComponent(query)}`;
                }
            }
        });
    },

    destroy() {
        if (this._unsub) this._unsub();
    }
};

export default SearchBar;
