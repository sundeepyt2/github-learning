const AniPubAPI = {
    BASE_URL: 'https://api.anipub.xyz',
    _cache: new Map(),
    _cacheDuration: 300000,

    async _fetch(endpoint) {
        const cached = this._cache.get(endpoint);
        if (cached && Date.now() - cached.time < this._cacheDuration) {
            return cached.data;
        }

        const response = await fetch(`${this.BASE_URL}${endpoint}`);
        if (!response.ok) throw new Error(`AniPub error: ${response.status}`);
        const data = await response.json();

        if (!data) throw new Error('AniPub returned empty response');
        this._cache.set(endpoint, { data, time: Date.now() });
        return data;
    },

    async search(query) { return this._fetch(`/api/search/${encodeURIComponent(query)}`); },
    async getInfo(idOrSlug) { return this._fetch(`/api/info/${idOrSlug}`); },
    // TODO: Verify these endpoints against actual AniPub API docs
    async getStreamingLinks(id) { return this._fetch(`/v1/api/details/${id}`); },
    async getFullDetails(id) { return this._fetch(`/anime/api/details/${id}`); },
    async getTopRated(page = 1) { return this._fetch(`/api/findbyrating?page=${page}`); },
    async getByGenre(genre, page = 1) {
        // TODO: Verify casing (findbyGenre vs findByGenre) and Page vs page
        return this._fetch(`/api/findbyGenre/${genre}?Page=${page}`);
    },
    // WARNING: /api/getAll may return a very large payload. Avoid calling from the client.
    async getTotal() { return this._fetch('/api/getAll'); }
};

export default AniPubAPI;
