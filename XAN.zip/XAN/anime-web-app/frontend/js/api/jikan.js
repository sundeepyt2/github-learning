const JikanAPI = {
    BASE_URL: 'http://localhost:5000/api',
    _cache: new Map(),
    _cacheDuration: 60000,

    async _fetch(endpoint, params = {}) {
        const cacheKey = endpoint + JSON.stringify(params);
        const cached = this._cache.get(cacheKey);
        if (cached && Date.now() - cached.time < this._cacheDuration) {
            return cached.data;
        }

        const url = new URL(this.BASE_URL + endpoint);
        Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));

        const response = await fetch(url);
        if (!response.ok) throw new Error(`API error: ${response.status}`);
        const data = await response.json();

        this._cache.set(cacheKey, { data, time: Date.now() });
        return data;
    },

    async getPopular() { return this._fetch('/anime'); },
    async getAnimeById(id) { return this._fetch(`/anime/${id}`); },
    async search(query, page = 1, adult = false) {
        return this._fetch('/search', { q: query, page, adult: adult ? 'true' : 'false' });
    },
    async getGenres() { return this._fetch('/genres'); },
    async getByGenre(genreId, page = 1, adult = false) {
        return this._fetch('/genre/' + genreId, { page, adult: adult ? 'true' : 'false' });
    },
    async getTop(filter = 'bypopularity', adult = false) {
        return this._fetch('/top', { filter, adult: adult ? 'true' : 'false' });
    },
    async getRandom() { return this._fetch('/random'); },
    async getRecommendations(id) { return this._fetch(`/anime/${id}/recommendations`); },
    async getCharacters(id) { return this._fetch(`/anime/${id}/characters`); }
};

export default JikanAPI;
